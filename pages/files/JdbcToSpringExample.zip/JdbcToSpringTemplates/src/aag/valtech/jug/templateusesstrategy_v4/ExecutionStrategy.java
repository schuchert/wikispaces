package aag.valtech.jug.templateusesstrategy_v4;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public interface ExecutionStrategy {
    void execute(PreparedStatement ps) throws SQLException;
}
