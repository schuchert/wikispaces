package aaa.valtech.jug.version1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import loggingutil.ILogger;
import loggingutil.LoggingConfiguration;

import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.valtech.util.DatabaseUtil;

public class JdbcExample {
    private static final ILogger logger = LoggingConfiguration.getLoggerFor(JdbcExample.class);
    private final DriverManagerDataSource dataSource;

    public static final String CREATE_TABLE = "CREATE TABLE customer (First_Name char(50), Last_Name char(50))";

    public static final String INSERT = "INSERT INTO customer (First_Name, Last_Name) VALUES (?, ?)";

    public static final String SELECT_BY_FIRST = "SELECT First_Name, Last_Name from Customer where First_Name = ?";

    public JdbcExample() {
        dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
        dataSource.setUrl("jdbc:hsqldb:mem:mem:aname");
        dataSource.setUsername("sa");
        dataSource.setPassword("");
    }

    public void installSchema() throws SQLException {
        Connection c = null; // NOPMD by brett.schuchert on 7/11/06 11:09 PM
        Statement s = null; // NOPMD by brett.schuchert on 7/11/06 11:09 PM

        try {
            c = dataSource.getConnection();
            s = c.createStatement();
            s.executeUpdate(CREATE_TABLE);
        } finally {
            DatabaseUtil.close(s);
            DatabaseUtil.close(c);
        }
    }

    public void populateTables() throws SQLException {
        Connection c = null; // NOPMD by brett.schuchert on 7/11/06 11:09 PM
        PreparedStatement ps = null;

        try {
            c = dataSource.getConnection();
            ps = c.prepareStatement(INSERT);
            insertOneRecord(ps, "Brett", "Schuchert");
            insertOneRecord(ps, "Jeana", "Smith");
            insertOneRecord(ps, "Brett", "Anotherone");
        } finally {
            DatabaseUtil.close(ps);
            DatabaseUtil.close(c);
        }
    }

    private void insertOneRecord(final PreparedStatement ps, final String firstName,
            final String lastName) throws SQLException {
        ps.setString(1, firstName);
        ps.setString(2, lastName);
        ps.executeUpdate();
    }

    public void performSearch() throws SQLException {
        Connection c = null; // NOPMD by brett.schuchert on 7/11/06 11:09 PM
        PreparedStatement ps = null;
        ResultSet rs = null; // NOPMD by brett.schuchert on 7/11/06 11:09 PM

        try {
            c = dataSource.getConnection();
            ps = c.prepareStatement(SELECT_BY_FIRST);
            ps.setString(1, "Brett");
            rs = ps.executeQuery();
            logger.debug("Records found:");
            while (rs.next()) {
                logger.debug("\n\t%s %s", rs.getString(1), rs.getString(2));
            }
        } finally {
            DatabaseUtil.close(rs);
            DatabaseUtil.close(ps);
            DatabaseUtil.close(c);
        }
    }

    public static void main(final String args[]) throws SQLException {
        logger.info("Version 1");

        final JdbcExample e = new JdbcExample();
        e.installSchema();
        e.populateTables();
        e.performSearch();
    }
}
