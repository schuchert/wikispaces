package aad.valtech.jug.templateusesstrategy;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import loggingutil.ILogger;
import loggingutil.LoggingConfiguration;

import com.valtech.util.DatabaseUtil;

public class PerformSearchStrategy implements ExecutionStrategy {
    private static final ILogger logger = LoggingConfiguration
            .getLoggerFor(PerformSearchStrategy.class);
    public static final String SELECT_BY_FIRST = "SELECT First_Name, Last_Name from Customer where First_Name = ?";

    public String getSql() {
        return SELECT_BY_FIRST;
    }

    public void execute(final PreparedStatement ps) throws SQLException {
        ps.setString(1, "Brett");
        final ResultSet rs = ps.executeQuery(); // NOPMD by brett.schuchert
        logger.info("Records found:");
        try {
            while (rs.next()) {
                logger.info("\n\t%s %s", rs.getString(1), rs.getString(2));
            }
        } finally {
            DatabaseUtil.close(rs);
        }
    }

}
