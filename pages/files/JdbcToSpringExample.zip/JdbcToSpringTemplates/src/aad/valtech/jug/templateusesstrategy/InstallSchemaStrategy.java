package aad.valtech.jug.templateusesstrategy;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InstallSchemaStrategy implements ExecutionStrategy {
    public static final String CREATE_TABLE = "CREATE TABLE customer (First_Name char(50), Last_Name char(50))";

    public String getSql() {
        return CREATE_TABLE;
    }

    public void execute(final PreparedStatement ps) throws SQLException {
        ps.execute();
    }
}
