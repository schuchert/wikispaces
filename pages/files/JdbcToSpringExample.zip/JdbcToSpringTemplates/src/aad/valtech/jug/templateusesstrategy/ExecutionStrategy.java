package aad.valtech.jug.templateusesstrategy;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public interface ExecutionStrategy {
    void execute(PreparedStatement ps) throws SQLException;

    String getSql();
}
