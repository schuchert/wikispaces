package aad.valtech.jug.templateusesstrategy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.valtech.util.DatabaseUtil;

public class TemplateStrategy {

    private final DriverManagerDataSource dataSource;

    public TemplateStrategy() {
        dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
        dataSource.setUrl("jdbc:hsqldb:mem:mem:aname");
        dataSource.setUsername("sa");
        dataSource.setPassword("");
    }

    public void execute(final ExecutionStrategy es) throws SQLException {
        Connection c = null; // NOPMD by brett.schuchert on 7/12/06 12:16 AM
        PreparedStatement ps = null;

        try {
            c = dataSource.getConnection();
            ps = c.prepareStatement(es.getSql());
            es.execute(ps);
        } finally {
            DatabaseUtil.close(ps);
            DatabaseUtil.close(c);
        }

    }
}
