package aad.valtech.jug.templateusesstrategy;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PopulateTablesStrategy implements ExecutionStrategy {
    public static final String INSERT = "INSERT INTO customer (First_Name, Last_Name) VALUES (?, ?)";

    public void execute(final PreparedStatement ps) throws SQLException {
        insertOneRecord(ps, "Brett", "Schuchert");
        insertOneRecord(ps, "Jeana", "Smith");
        insertOneRecord(ps, "Brett", "Anotherone");
    }

    private void insertOneRecord(final PreparedStatement ps, final String firstName,
            final String lastName) throws SQLException {
        ps.setString(1, firstName);
        ps.setString(2, lastName);
        ps.executeUpdate();
    }

    public String getSql() {
        return INSERT;
    }

}
