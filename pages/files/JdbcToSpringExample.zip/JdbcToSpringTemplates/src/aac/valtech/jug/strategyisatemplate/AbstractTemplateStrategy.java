package aac.valtech.jug.strategyisatemplate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.valtech.util.DatabaseUtil;

public abstract class AbstractTemplateStrategy {

    private final DriverManagerDataSource dataSource;

    public AbstractTemplateStrategy() {
        dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
        dataSource.setUrl("jdbc:hsqldb:mem:mem:aname");
        dataSource.setUsername("sa");
        dataSource.setPassword("");
    }

    public void execute() throws SQLException {
        Connection c = null; // NOPMD by brett.schuchert on 7/12/06 12:03 AM
        PreparedStatement ps = null;

        try {
            c = dataSource.getConnection();
            ps = c.prepareStatement(getSql());
            executeImpl(ps);
        } finally {
            DatabaseUtil.close(ps);
            DatabaseUtil.close(c);
        }

    }

    protected abstract String getSql();

    protected abstract void executeImpl(PreparedStatement ps) throws SQLException;
}
