package aac.valtech.jug.strategyisatemplate;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InstallSchemaStrategy extends AbstractTemplateStrategy {
    public static final String CREATE_TABLE = "CREATE TABLE customer (First_Name char(50), Last_Name char(50))";

    @Override
    protected String getSql() {
        return CREATE_TABLE;
    }

    @Override
    protected void executeImpl(final PreparedStatement ps) throws SQLException {
        ps.execute();
    }

}
