package aac.valtech.jug.strategyisatemplate;

import java.sql.SQLException;

import loggingutil.ILogger;
import loggingutil.LoggingConfiguration;

public class JdbcExample {
    private JdbcExample() {
        // do not instantiate me
    }

    private static final ILogger logger = LoggingConfiguration.getLoggerFor(JdbcExample.class);

    /**
     * @param args
     * @throws SQLException
     */
    public static void main(final String[] args) throws SQLException {
        logger.info("Version 3");

        final InstallSchemaStrategy iss = new InstallSchemaStrategy();
        final PopulateTablesStrategy pts = new PopulateTablesStrategy();
        final PerformSearchStrategy pss = new PerformSearchStrategy();

        iss.execute();
        pts.execute();
        pss.execute();
    }

}
