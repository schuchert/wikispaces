package aaf.valtech.jug.templateusesstrategy_v3;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public interface ExecutionStrategy {
    void execute(PreparedStatement ps) throws SQLException;
}
