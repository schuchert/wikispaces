package aaf.valtech.jug.templateusesstrategy_v3;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import loggingutil.ILogger;
import loggingutil.LoggingConfiguration;

import com.valtech.util.DatabaseUtil;

public class JdbcExample {
    private JdbcExample() {
        // do not instantiate me
    }

    private static final ILogger logger = LoggingConfiguration.getLoggerFor(JdbcExample.class);
    public static final String CREATE_TABLE = "CREATE TABLE customer (First_Name char(50), Last_Name char(50))";

    public static final String INSERT = "INSERT INTO customer (First_Name, Last_Name) VALUES (?, ?)";

    public static final String SELECT_BY_FIRST = "SELECT First_Name, Last_Name from Customer where First_Name = ?";

    /**
     * @param args
     * @throws SQLException
     */
    public static void main(final String[] args) throws SQLException {
        logger.info("Version 6");

        final TemplateStrategy ts = new TemplateStrategy();

        ts.execute(CREATE_TABLE, new ExecutionStrategy() {
            public void execute(PreparedStatement ps) throws SQLException {
                ps.execute();
            }
        });

        final PopulateTablesStrategy pts = new PopulateTablesStrategy();
        ts.execute(INSERT, pts);

        ts.execute(SELECT_BY_FIRST, new ExecutionStrategy() {
            public void execute(PreparedStatement ps) throws SQLException {
                ps.setString(1, "Brett");
                final ResultSet rs = ps.executeQuery(); // NOPMD by

                try {
                    logger.info("Records found:");
                    while (rs.next()) {
                        logger.info("\n\t%s %s", rs.getString(1), rs.getString(2));
                    }
                } finally {
                    DatabaseUtil.close(rs);
                }
            }
        });
    }

}
