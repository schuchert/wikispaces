package com.valtech.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import loggingutil.ILogger;
import loggingutil.LoggingConfiguration;

public class DatabaseUtil {
    private static final ILogger logger = LoggingConfiguration.getLoggerFor(DatabaseUtil.class);

    private DatabaseUtil() {
        // I'm a util class
    }

    public static void close(final ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException e) {
            logger.error("Failed to close ResultSet", e);
        }
    }

    public static void close(final Statement s) {
        try {
            if (s != null) {
                s.close();
            }
        } catch (SQLException e) {
            logger.error("Failed to close Statement", e);
        }
    }

    public static void close(final Connection c) {
        try {
            if (c != null) {
                c.close();
            }
        } catch (SQLException e) {
            logger.error("Failed to close Connection", e);
        }
    }

}
