package aab.valtech.jug.templatemethod;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import loggingutil.ILogger;
import loggingutil.LoggingConfiguration;

import com.valtech.util.DatabaseUtil;

public class Example2 extends AbstractTemplateMethod {
    private static final ILogger logger = LoggingConfiguration
            .getLoggerFor(AbstractTemplateMethod.class);

    public static final String CREATE_TABLE = "CREATE TABLE customer (First_Name char(50), Last_Name char(50))";

    public static final String INSERT = "INSERT INTO customer (First_Name, Last_Name) VALUES (?, ?)";

    public static final String SELECT_BY_FIRST = "SELECT First_Name, Last_Name from Customer where First_Name = ?";

    @Override
    protected void installSchemaImpl(final Statement s) throws SQLException {
        s.executeUpdate(CREATE_TABLE);
    }

    @Override
    protected void populateTablesImpl(final PreparedStatement ps) throws SQLException {
        insertOneRecord(ps, "Brett", "Schuchert");
        insertOneRecord(ps, "Jeana", "Smith");
        insertOneRecord(ps, "Brett", "Anotherone");
    }

    private void insertOneRecord(final PreparedStatement ps, final String firstName,
            final String lastName) throws SQLException {
        ps.setString(1, firstName);
        ps.setString(2, lastName);
        ps.executeUpdate();
    }

    @Override
    protected String getInsertStatement() {
        return INSERT;
    }

    @Override
    protected void performSearchImpl(final PreparedStatement ps) throws SQLException {
        ps.setString(1, "Brett");
        final ResultSet rs = ps.executeQuery(); // NOPMD by brett.schuchert on
                                                // 7/11/06 11:25 PM
        logger.debug("Records found:");
        while (rs.next()) {
            logger.debug("\n\t%s %s", rs.getString(1), rs.getString(2));
        }
        DatabaseUtil.close(rs);
    }

    @Override
    protected String getSearchStatement() {
        return SELECT_BY_FIRST;
    }
}
