package aab.valtech.jug.templatemethod;

import java.sql.SQLException;

import loggingutil.ILogger;
import loggingutil.LoggingConfiguration;

public class JdbcExample {
    private JdbcExample() {
        // do not instantiate me
    }

    private static final ILogger logger = LoggingConfiguration.getLoggerFor(JdbcExample.class);

    public static void main(final String args[]) throws SQLException {
        logger.debug("Version 2");

        final Example2 e = new Example2();
        e.installSchema();
        e.populateTables();
        e.performSearch();
    }
}
