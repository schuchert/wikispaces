package aab.valtech.jug.templatemethod;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.valtech.util.DatabaseUtil;

public abstract class AbstractTemplateMethod {
    private final DriverManagerDataSource dataSource;

    public AbstractTemplateMethod() {
        dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
        dataSource.setUrl("jdbc:hsqldb:mem:mem:aname");
        dataSource.setUsername("sa");
        dataSource.setPassword("");
    }

    public void installSchema() throws SQLException {
        Connection c = null; // NOPMD by brett.schuchert on 7/11/06 11:27 PM
        Statement s = null; // NOPMD by brett.schuchert on 7/11/06 11:27 PM

        try {
            c = dataSource.getConnection();
            s = c.createStatement();
            installSchemaImpl(s);
        } finally {
            DatabaseUtil.close(s);
            DatabaseUtil.close(c);
        }
    }

    protected abstract void installSchemaImpl(Statement s) throws SQLException;

    public void populateTables() throws SQLException {
        Connection c = null; // NOPMD by brett.schuchert on 7/11/06 11:27 PM
        PreparedStatement ps = null;

        try {
            c = dataSource.getConnection();
            ps = c.prepareStatement(getInsertStatement());
            populateTablesImpl(ps);
        } finally {
            DatabaseUtil.close(ps);
            DatabaseUtil.close(c);
        }
    }

    protected abstract void populateTablesImpl(PreparedStatement ps) throws SQLException;

    protected abstract String getInsertStatement();

    public void performSearch() throws SQLException {
        Connection c = null; // NOPMD by brett.schuchert on 7/11/06 11:27 PM
        PreparedStatement ps = null;
        ResultSet rs = null; // NOPMD by brett.schuchert on 7/11/06 11:27 PM

        try {
            c = dataSource.getConnection();
            ps = c.prepareStatement(getSearchStatement());
            performSearchImpl(ps);
        } finally {
            DatabaseUtil.close(rs);
            DatabaseUtil.close(ps);
            DatabaseUtil.close(c);
        }
    }

    protected abstract void performSearchImpl(PreparedStatement ps) throws SQLException;

    protected abstract String getSearchStatement();
}
