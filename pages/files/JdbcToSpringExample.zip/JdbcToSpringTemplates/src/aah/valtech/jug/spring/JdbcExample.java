package aah.valtech.jug.spring;

import java.sql.ResultSet;
import java.sql.SQLException;

import loggingutil.ILogger;
import loggingutil.LoggingConfiguration;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class JdbcExample {
    private static final ILogger logger = LoggingConfiguration.getLoggerFor(JdbcExample.class);

    private final JdbcTemplate jdbcTemplate;

    public static final String CREATE_TABLE = "CREATE TABLE customer (First_Name char(50), Last_Name char(50))";

    public static final String INSERT = "INSERT INTO customer (First_Name, Last_Name) VALUES (?, ?)";

    public static final String SELECT_BY_FIRST = "SELECT First_Name, Last_Name from Customer where First_Name = ?";

    public JdbcExample() {
        final DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
        dataSource.setUrl("jdbc:hsqldb:mem:mem:aname");
        dataSource.setUsername("sa");
        dataSource.setPassword("");
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void installSchema() {
        jdbcTemplate.execute(CREATE_TABLE);
    }

    public void populateTables() {
        jdbcTemplate.update(INSERT, new Object[] { "Brett", "Schuchert" });
        jdbcTemplate.update(INSERT, new Object[] { "Jeana", "Smith" });
        jdbcTemplate.update(INSERT, new Object[] { "Brett", "Anotherone" });
    }

    public void performSearch() {
        jdbcTemplate.query(SELECT_BY_FIRST, new Object[] { "Brett" }, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                logger.error("%s %s\n", rs.getString(1), rs.getString(2));
            }
        });
    }

    public static void main(final String[] args) {
        logger.info("Version 8");

        final JdbcExample e = new JdbcExample();

        e.installSchema();
        e.populateTables();
        e.performSearch();
    }

}
