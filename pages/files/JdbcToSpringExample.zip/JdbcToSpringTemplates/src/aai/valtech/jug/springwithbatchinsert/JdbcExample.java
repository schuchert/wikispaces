package aai.valtech.jug.springwithbatchinsert;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import loggingutil.ILogger;
import loggingutil.LoggingConfiguration;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.object.BatchSqlUpdate;

public class JdbcExample {
    private static final ILogger logger = LoggingConfiguration.getLoggerFor(JdbcExample.class);

    private final DriverManagerDataSource dataSource;

    final private JdbcTemplate jdbcTemplate;

    public static final String CREATE_TABLE = "CREATE TABLE customer (First_Name char(50), Last_Name char(50))";

    public static final String INSERT = "INSERT INTO customer (First_Name, Last_Name) VALUES (?, ?)";

    public static final String SELECT_BY_FIRST = "SELECT First_Name, Last_Name from Customer where First_Name = ?";

    public JdbcExample() {
        dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
        dataSource.setUrl("jdbc:hsqldb:mem:mem:aname");
        dataSource.setUsername("sa");
        dataSource.setPassword("");
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void installSchema() {
        jdbcTemplate.execute(CREATE_TABLE);
    }

    public void populateTables() {
        final BatchSqlUpdate update = new BatchSqlUpdate(dataSource, INSERT);
        update.declareParameter(new SqlParameter("First_Name", Types.VARCHAR));
        update.declareParameter(new SqlParameter("Last_Name", Types.VARCHAR));
        update.update(new Object[] { "Brett", "Schuchert" });
        update.update(new Object[] { "Jeana", "Smith" });
        update.update(new Object[] { "Brett", "Anotherone" });
        update.flush();
    }

    public void performSearch() {
        jdbcTemplate.query(SELECT_BY_FIRST, new Object[] { "Brett" }, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                logger.error("%s %s\n", rs.getString(1), rs.getString(2));
            }
        });
    }

    public static void main(final String[] args) {
        logger.info("Version 9");

        final JdbcExample e = new JdbcExample();

        e.installSchema();
        e.populateTables();
        e.performSearch();
    }

}
