package aae.valtech.jug.templateusesstrategy_v2;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InstallSchemaStrategy implements ExecutionStrategy {
    public void execute(final PreparedStatement ps) throws SQLException {
        ps.execute();
    }
}
