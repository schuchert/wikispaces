package aae.valtech.jug.templateusesstrategy_v2;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public interface ExecutionStrategy {
    void execute(PreparedStatement ps) throws SQLException;
}
