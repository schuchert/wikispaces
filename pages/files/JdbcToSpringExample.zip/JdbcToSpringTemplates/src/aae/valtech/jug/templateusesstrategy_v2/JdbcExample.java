package aae.valtech.jug.templateusesstrategy_v2;

import java.sql.SQLException;

import loggingutil.ILogger;
import loggingutil.LoggingConfiguration;

public class JdbcExample {
    private JdbcExample() {
        // do not instantiate me
    }

    private static final ILogger logger = LoggingConfiguration.getLoggerFor(JdbcExample.class);

    /**
     * @param args
     * @throws SQLException
     */
    public static void main(final String[] args) throws SQLException {
        logger.info("Version 5");

        final TemplateStrategy ts = new TemplateStrategy();
        final InstallSchemaStrategy iss = new InstallSchemaStrategy();
        final PopulateTablesStrategy pts = new PopulateTablesStrategy();
        final PerformSearchStrategy pss = new PerformSearchStrategy();

        ts.execute("CREATE TABLE customer (First_Name char(50), Last_Name char(50))", iss);
        ts.execute("INSERT INTO customer (First_Name, Last_Name) VALUES (?, ?)", pts);
        ts.execute("SELECT First_Name, Last_Name from Customer where First_Name = ?", pss);
    }

}
