package aae.valtech.jug.templateusesstrategy_v2;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PopulateTablesStrategy implements ExecutionStrategy {
    public void execute(final PreparedStatement ps) throws SQLException {
        insertOneRecord(ps, "Brett", "Schuchert");
        insertOneRecord(ps, "Jeana", "Smith");
        insertOneRecord(ps, "Brett", "Anotherone");
    }

    private void insertOneRecord(final PreparedStatement ps, final String firstName,
            final String lastName) throws SQLException {
        ps.setString(1, firstName);
        ps.setString(2, lastName);
        ps.executeUpdate();
    }
}
