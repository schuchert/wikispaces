package aae.valtech.jug.templateusesstrategy_v2;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import loggingutil.ILogger;
import loggingutil.LoggingConfiguration;

import com.valtech.util.DatabaseUtil;

public class PerformSearchStrategy implements ExecutionStrategy {
    private static final ILogger logger = LoggingConfiguration
            .getLoggerFor(PerformSearchStrategy.class);

    public void execute(final PreparedStatement ps) throws SQLException {
        ps.setString(1, "Brett");
        final ResultSet rs = ps.executeQuery(); // NOPMD by brett.schuchert
        logger.info("Records found:");
        try {
            while (rs.next()) {
                logger.info("\n\t%s %s", rs.getString(1), rs.getString(2));
            }
        } finally {
            DatabaseUtil.close(rs);
        }
    }

}
