package aae.valtech.jug.templateusesstrategy_v2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.valtech.util.DatabaseUtil;

public class TemplateStrategy {

    private final DriverManagerDataSource dataSource;

    public TemplateStrategy() {
        dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
        dataSource.setUrl("jdbc:hsqldb:mem:mem:aname");
        dataSource.setUsername("sa");
        dataSource.setPassword("");
    }

    public void execute(final String sql, final ExecutionStrategy es) throws SQLException {
        Connection c = null; // NOPMD by brett.schuchert on 7/12/06 12:14 AM
        PreparedStatement ps = null;

        try {
            c = dataSource.getConnection();
            ps = c.prepareStatement(sql);
            es.execute(ps);
        } finally {
            DatabaseUtil.close(ps);
            DatabaseUtil.close(c);
        }

    }
}
