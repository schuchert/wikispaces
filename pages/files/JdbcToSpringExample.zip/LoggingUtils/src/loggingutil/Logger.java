package loggingutil;

import org.apache.log4j.Level;

public class Logger implements ILogger {
    private final org.apache.log4j.Logger wrappedLogger;

    public Logger(final org.apache.log4j.Logger logger) {
        this.wrappedLogger = logger;
    }

    public ILogger debug(final String formatString, final Object... params) {
        if (wrappedLogger.isDebugEnabled()) {
            wrappedLogger.debug(String.format(formatString, params));
        }
        return this;
    }

    public ILogger debug(final Throwable t, final String formatString, final Object... params) {
        if (wrappedLogger.isDebugEnabled()) {
            wrappedLogger.debug(String.format(formatString, params), t);
        }
        return this;
    }

    public ILogger warn(final String formatString, final Object... params) {
        if (wrappedLogger.isEnabledFor(Level.WARN)) {
            wrappedLogger.warn(String.format(formatString, params));
        }
        return this;
    }

    public ILogger warn(final Throwable t, final String formatString, final Object... params) {
        if (wrappedLogger.isEnabledFor(Level.WARN)) {
            wrappedLogger.warn(String.format(formatString, params), t);
        }
        return this;
    }

    public ILogger info(final String formatString, final Object... params) {
        if (wrappedLogger.isEnabledFor(Level.INFO)) {
            wrappedLogger.info(String.format(formatString, params));
        }
        return this;
    }

    public ILogger info(final Throwable t, final String formatString, final Object... params) {
        if (wrappedLogger.isEnabledFor(Level.INFO)) {
            wrappedLogger.info(String.format(formatString, params), t);
        }
        return this;
    }

    public ILogger error(final String formatString, final Object... params) {
        if (wrappedLogger.isEnabledFor(Level.ERROR)) {
            wrappedLogger.error(String.format(formatString, params));
        }
        return this;
    }

    public ILogger error(final Throwable t, final String formatString, final Object... params) {
        if (wrappedLogger.isEnabledFor(Level.ERROR)) {
            wrappedLogger.error(String.format(formatString, params), t);
        }
        return this;
    }

    public ILogger fatal(final String formatString, final Object... params) {
        if (wrappedLogger.isEnabledFor(Level.FATAL)) {
            wrappedLogger.fatal(String.format(formatString, params));
        }
        return this;
    }

    public ILogger fatal(final Throwable t, final String formatString, final Object... params) {
        if (wrappedLogger.isEnabledFor(Level.FATAL)) {
            wrappedLogger.fatal(String.format(formatString, params), t);
        }
        return this;
    }
}
