package loggingutil;

public interface ILogger {
    ILogger debug(final String formatString, final Object... params);

    ILogger debug(final Throwable t, final String formatString, final Object... params);

    ILogger warn(final String formatString, final Object... params);

    ILogger warn(final Throwable t, final String formatString, final Object... params);

    ILogger info(final String formatString, final Object... params);

    ILogger info(final Throwable t, final String formatString, final Object... params);

    ILogger error(final String formatString, final Object... params);

    ILogger error(final Throwable t, final String formatString, final Object... params);

    ILogger fatal(final String formatString, final Object... params);

    ILogger fatal(final Throwable t, final String formatString, final Object... params);
}
