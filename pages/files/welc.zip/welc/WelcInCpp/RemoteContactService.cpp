
#include "RemoteContactService.h"


string RemoteContactService::getSubscriberBase(const string& name, const string& department)
{
	return "";
}

string RemoteContactService::getContactInfo(const string& name)
{
	return "";
}

