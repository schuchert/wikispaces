


#include "cuultralight.h"
#include "Scheduler.h"
#include "Meeting.h"
#include "DayTime.h"
#include "Date.h"

#include <string>


TEST(test, scheduler)
{
	Scheduler scheduler("Fred");

	ASSERT_EQUAL("", "1");
}



