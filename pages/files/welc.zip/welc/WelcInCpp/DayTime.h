

#ifndef DAYTIME_H
#define DAYTIME_H


enum DayTime
{
	Time8AM = 0,
	Time9AM,
	Time10AM,
	Time11AM,
	Time12PM,
	Time1PM,
	Time2PM,
	Time3PM,
	Time4PM,
	Time5PM,
	Time6PM,
	Time7PM,
	Time8PM,
};


#endif 



