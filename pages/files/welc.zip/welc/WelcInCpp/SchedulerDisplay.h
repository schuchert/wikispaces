

#ifndef SCHEDULER_DISPLAY
#define SCHEDULER_DISPLAY

class Event;


class SchedulerDisplay
{
public:
	void ShowEvent(Event *event);

};

#endif