
#ifndef JOB_H
#define JOB_H

#include <string>

using namespace std;

class Job
{
public:
	string description() { return ""; }
};

#endif