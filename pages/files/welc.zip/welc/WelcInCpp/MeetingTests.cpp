

#include "TestHarness.h"
#include "Meeting.h"

extern SimpleString StringFrom(Date date);
