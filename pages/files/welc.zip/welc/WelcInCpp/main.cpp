

#include "TestHarness.h"


int test_failures = 0;

void testExample() 
{
	CHECK(true);
	CHECK_EQUAL(12,24);
	CHECK_EQUAL("12", "14");
}

int
main() {
	test_failures = 0;

	testExample();

	printf("\nNumber of Failures: %d\n", test_failures);
	return 0;
}