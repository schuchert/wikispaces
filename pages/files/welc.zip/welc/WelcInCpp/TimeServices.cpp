
#include "TimeServices.h"



bool TimeServices::isPastDue(Date date)
{
	return false;
}

bool TimeServices::isWorkday(Date date)
{
	return false;
}

bool TimeServices::isHoliday(Date date)
{
	return false;
}

