#Generated file - cleanAll.sh
echo "Running cleanAll for CppUTest v2.2e created on 2010-11-27-19-43"
export CPPUTEST_HOME=$(pwd)
echo "export CPPUTEST_HOME=$(pwd)/"
make cleanEverythingInstall
