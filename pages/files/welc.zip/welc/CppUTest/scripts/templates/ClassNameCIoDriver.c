#include "ClassName.h"
#include "IO.h"
//static local variables


void ClassName_Create(void)
{
}

void ClassName_Destroy(void)
{
}


