package schuchert.agent;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;

import org.junit.Test;

public class ManifestTest {
    public static final String EXPECTED = String.format("Premain-Class: %s",
            ConfigurableClassFileTransformerRegistrar.class.getName());

    public static final String ERROR_MESSAGE = String.format("Did not find line matching: '%s' -- was class renamed?",
            EXPECTED);

    @Test
    public void manifestHasCorrectClassName() throws Exception {
        FileReader reader = null;

        try {
            reader = retrieveThisProjectsManifest();
            assertTrue(ERROR_MESSAGE, foundPremainClassLineWithCorrectClassName(reader));
        } finally {
            closeIfNotNull(reader);
        }
    }

    private boolean foundPremainClassLineWithCorrectClassName(Reader reader) throws Exception {
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(reader);
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                if (line.equals(EXPECTED))
                    return true;
            }
        } finally {
            closeIfNotNull(bufferedReader);
        }

        return false;
    }

    private FileReader retrieveThisProjectsManifest() throws FileNotFoundException {
        FileReader reader = new FileReader("META-INF/MANIFEST.MF");
        assertNotNull(reader);
        return reader;
    }

    private void closeIfNotNull(Reader reader) throws Exception {
        if (reader != null)
            reader.close();
    }
}
