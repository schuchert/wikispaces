package schuchert.agent;

public class Main {
    private static final String PROPERTY_NAME = ConfigurableClassFileTransformerRegistrar.DEST_CLASS_PROPERTY_NAME;

    public static void main(String[] args) {
        if (atLeastOneClassRegistered() && systemPropertySet())
            System.out.printf("Congratulations, everything appears to be working\n");
        else
            usage();
    }

    private static void usage() {
        System.out.printf(
                "No ClassFileTransformers\n\tadded by: %s\n\tusing system property: %s\n",
                ConfigurableClassFileTransformerRegistrar.class.getName(), PROPERTY_NAME);

        System.out.printf("When starting VM, please specify the following two VM arguments:"
                + "\n\t-javaagent:Registrar.jar (or the name you're using)\n\t"
                + "-D%1$s=<SomeClassInClassPath>\n\t\t(e.g. %1$s=%2$s)\n", PROPERTY_NAME,
                NullClassFileTransformer.class.getName());
    }

    private static boolean atLeastOneClassRegistered() {
        return ConfigurableClassFileTransformerRegistrar.iterator().hasNext();
    }

    private static boolean systemPropertySet() {
        return System.getProperty(PROPERTY_NAME) != null;
    }
}
