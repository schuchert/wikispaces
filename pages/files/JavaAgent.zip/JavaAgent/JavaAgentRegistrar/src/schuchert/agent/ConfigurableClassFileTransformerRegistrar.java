package schuchert.agent;

import java.io.PrintStream;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

public class ConfigurableClassFileTransformerRegistrar {
    private static List<ClassFileTransformer> registeredTransformers = new ArrayList<ClassFileTransformer>();

    public static final String DEST_CLASS_PROPERTY_NAME = "schuchert.ClassFileTransformer";

    static final String INSTANTIATION_ERROR = "Unable to instantiate: %s\n";
    static final String CHECK_SYSTEM_PROPERTY_MESSAGE = "Please check setting for system property: %s\n";
    static final String EXAMPLE_MESSAGE = "e.g. -D%s=%s\n";

    static PrintStream ERROR_OUT = System.err;

    public static void premain(String agentArguments, Instrumentation instrumentation) {
        for (String className : getClassNames()) {
            addOneClassFileTransformer(instrumentation, className);
        }
    }

    public static Iterator<ClassFileTransformer> iterator() {
        return registeredTransformers.iterator();
    }

    private static void addOneClassFileTransformer(Instrumentation instrumentation, String className) {
        ClassFileTransformer classFileTransformer = createTargetTransformer(className);
        if (classFileTransformer != null) {
            instrumentation.addTransformer(classFileTransformer);
            registeredTransformers.add(classFileTransformer);
        }
    }

    private static ClassFileTransformer createTargetTransformer(String className) {
        ClassFileTransformer targetTransformer = null;

        if (className != null) {
            try {
                Class<?> targetTransformerClass = Class.forName(className);
                targetTransformer = (ClassFileTransformer) targetTransformerClass.newInstance();
            } catch (Exception e) {
                reportException(e, className);
            }
        }

        return targetTransformer;

    }

    private static String[] getClassNames() {
        String classNameList = System.getProperty(DEST_CLASS_PROPERTY_NAME);

        if (classNameListMissingOrEmpty(classNameList)) {
            reportUsage();
            return new String[] {};
        }

        String[] classNames = classNameList.split(":");
        for (int i = 0; i < classNames.length; ++i) {
            classNames[i] = classNames[i].trim();
        }
        return classNames;
    }

    private static boolean classNameListMissingOrEmpty(String classNameList) {
        return classNameList == null || classNameList.trim().length() == 0;
    }

    private static void reportException(Exception e, String className) {
        e.printStackTrace(ERROR_OUT);
        ERROR_OUT.printf(INSTANTIATION_ERROR, className);
        reportUsage();
    }

    private static void reportUsage() {
        ERROR_OUT.printf(CHECK_SYSTEM_PROPERTY_MESSAGE, DEST_CLASS_PROPERTY_NAME);
        ERROR_OUT.printf(EXAMPLE_MESSAGE, DEST_CLASS_PROPERTY_NAME, NullClassFileTransformer.class.getName());
    }
}
