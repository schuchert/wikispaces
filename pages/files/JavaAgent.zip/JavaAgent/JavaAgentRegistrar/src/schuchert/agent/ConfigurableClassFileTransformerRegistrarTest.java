package schuchert.agent;

import java.io.PrintStream;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.util.Properties;

import junit.framework.Assert;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import util.MockeryUtil;

@RunWith(JMock.class)
public class ConfigurableClassFileTransformerRegistrarTest {
    Mockery context = MockeryUtil.createMockeryForConcreteClasses();
    Instrumentation insrumentationSpy;
    PrintStream errorOutSpy;

    @Before
    public void createInsrumentationSpy() {
        insrumentationSpy = context.mock(Instrumentation.class);
    }

    @Before
    public void createAndRegisterErrorOutSpy() {
        errorOutSpy = context.mock(PrintStream.class);
        ConfigurableClassFileTransformerRegistrar.ERROR_OUT = errorOutSpy;
    }

    @Before
    public void clearSystemProperty() {
        Properties systemProperties = System.getProperties();
        systemProperties.remove(ConfigurableClassFileTransformerRegistrar.DEST_CLASS_PROPERTY_NAME);
        System.setProperties(systemProperties);
        Assert.assertNull(System.getProperty(ConfigurableClassFileTransformerRegistrar.DEST_CLASS_PROPERTY_NAME));
    }

    @Test
    public void errorReportedAndNoClassRegisteredWhenNoSystemPropertyDefined() {
        expectMissingSystemPropertyMessage();
        ConfigurableClassFileTransformerRegistrar.premain("", insrumentationSpy);
    }

    @Test
    public void systemPropertyDefinedButNullAlwaysPassesBecuaseNotPossibleToCreaetNullSystemProperty() {
    }

    @Test
    public void missingSystemPropertyReportedAndNoClassRegisteredWhenSystemPropertyEmptyString() {
        expectMissingSystemPropertyMessage();

        setSystemProperty("");

        ConfigurableClassFileTransformerRegistrar.premain("", insrumentationSpy);
    }

    @Test
    public void missingSystemPropertyReportedAndNoClassRegisteredWhenSystemPropertyContainsNothingButSpaces() {
        expectMissingSystemPropertyMessage();

        setSystemProperty("   ");

        ConfigurableClassFileTransformerRegistrar.premain("", insrumentationSpy);
    }

    @Test
    public void noErrorsWhenSystemPropertySetToSingleClassThatExistsInClassPath() {
        expectRegistryOfNullClassFileTransformer();

        setSystemProperty(NullClassFileTransformer.class.getName());

        ConfigurableClassFileTransformerRegistrar.premain("", insrumentationSpy);
    }

    @Test
    public void noErrorsWhenSystemPropertySetToSingleClassWithSpacesOnEndsThatExistsInClassPath() {
        expectRegistryOfNullClassFileTransformer();

        setSystemProperty("   " + NullClassFileTransformer.class.getName() + "   ");

        ConfigurableClassFileTransformerRegistrar.premain("", insrumentationSpy);
    }

    @Test
    public void noErrorsWhenSystemPropertySetToMultipleClassesAllOfWhichAreInClassPath() {
        expectRegistryOfNullClassFileTransformer();
        expectRegistryOf(ClassAndPackageNamePrintingClassFileTransformer.class);

        setSystemProperty(NullClassFileTransformer.class.getName() + ":"
                + ClassAndPackageNamePrintingClassFileTransformer.class.getName());

        ConfigurableClassFileTransformerRegistrar.premain("", insrumentationSpy);
    }

    @Test
    public void noErrorsWhenSystemPropertySetToMultipleClassesWithSpacesAtEndsOfNames() {
        expectRegistryOfNullClassFileTransformer();
        expectRegistryOf(ClassAndPackageNamePrintingClassFileTransformer.class);

        setSystemProperty(" " + NullClassFileTransformer.class.getName() + " : "
                + ClassAndPackageNamePrintingClassFileTransformer.class.getName() + " ");

        ConfigurableClassFileTransformerRegistrar.premain("", insrumentationSpy);
    }

    @Test
    public void noClassRegisteredWhenSingleMissingClassInSystemProperty() {
        expectReportOfClassNotFound();

        setSystemProperty("MissingClassThatShouldNotExistInClassPathEver");

        ConfigurableClassFileTransformerRegistrar.premain("", insrumentationSpy);
    }

    @Test
    public void nullTransformerRegisteredWhenSingleBadClassNameInSystemProperty() {
        expectReportOfClassNotFound();

        setSystemProperty("InvalidClassName^^^^");

        ConfigurableClassFileTransformerRegistrar.premain("", insrumentationSpy);
    }

    @Test
    public void nullTransformerRegisteredForEachBadClassWhenBothGoodAndBadClassNamesInSystemProperty() {
        expectRegistryOfNullClassFileTransformer();
        expectReportOfClassNotFound();
        expectRegistryOf(ClassAndPackageNamePrintingClassFileTransformer.class);

        setSystemProperty(NullClassFileTransformer.class.getName() + ":InvalidClassname^^^:"
                + ClassAndPackageNamePrintingClassFileTransformer.class.getName());

        ConfigurableClassFileTransformerRegistrar.premain("", insrumentationSpy);
    }

    @Test
    public void classNotImplementingClassFileFormaterErrorReported() {
        expectClassCastException();
        expectReportOfMissingClass();
        expectMissingSystemPropertyMessage();

        setSystemProperty(getClass().getName());

        ConfigurableClassFileTransformerRegistrar.premain("", insrumentationSpy);
    }

    private void setSystemProperty(String value) {
        System.setProperty(ConfigurableClassFileTransformerRegistrar.DEST_CLASS_PROPERTY_NAME, value);
    }

    private void expectMissingSystemPropertyMessage() {
        context.checking(new Expectations() {
            {
                one(errorOutSpy).printf(with(equal(ConfigurableClassFileTransformerRegistrar.CHECK_SYSTEM_PROPERTY_MESSAGE)),
                        with(any(String.class)));
                one(errorOutSpy).printf(with(equal(ConfigurableClassFileTransformerRegistrar.EXAMPLE_MESSAGE)),
                        with(any(Object.class)));
            }
        });
    }

    private void expectRegistryOfNullClassFileTransformer() {
        expectRegistryOf(NullClassFileTransformer.class);
    }

    private void expectRegistryOf(final Class<?> clazz) {
        context.checking(new Expectations() {
            {
                one(insrumentationSpy).addTransformer((ClassFileTransformer) with(any(clazz)));
            }
        });
    }

    private void expectReportOfMissingClass() {
        context.checking(new Expectations() {
            {
                one(errorOutSpy).printf(with(equal(ConfigurableClassFileTransformerRegistrar.INSTANTIATION_ERROR)),
                        with(any(String.class)));
            }
        });

    }

    private void expectClassNotFoundExceptionReported() {
        context.checking(new Expectations() {
            {
                one(errorOutSpy).println(with(any(ClassNotFoundException.class)));
                ignoring(errorOutSpy).println(with(any(String.class)));
            }
        });
    }

    private void expectReportOfClassNotFound() {
        expectClassNotFoundExceptionReported();
        expectReportOfMissingClass();
        expectMissingSystemPropertyMessage();
    }

    private void expectClassCastException() {
        context.checking(new Expectations() {
            {
                one(errorOutSpy).println(with(any(ClassCastException.class)));
                ignoring(errorOutSpy).println(with(any(String.class)));
            }
        });

    }

}
