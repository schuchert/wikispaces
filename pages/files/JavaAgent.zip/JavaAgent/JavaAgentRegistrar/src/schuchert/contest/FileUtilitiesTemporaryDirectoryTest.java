package schuchert.contest;

import static junit.framework.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.junit.After;
import org.junit.Test;

public class FileUtilitiesTemporaryDirectoryTest {
    private static final String TEMP_DIR_NAME = "TEST_TEMP_DIR";
    static boolean tempDirExistedBeforeTestStarted;

    @After
    public void removeTempDirectory() {
        File tempDirecotry = new File(TEMP_DIR_NAME);
        FileUtilities.clearAllFiles(tempDirecotry);
        tempDirecotry.delete();
    }

    @Test
    public void tempDirectoryExistsAsFileIsRemovedAndRecreatedAsDirectory() throws Exception {
        File fileCreated = createFileNamed(TEMP_DIR_NAME);
        callAndValidateTempDirectoryCreation();
        fileCreated.delete();
    }

    @Test
    public void tempDirectoryExistsAsDirectoryThatIsEmptyAndIsRecreatedAsEmptyDirectory()
            throws Exception {
        createTempDirectory();
        callAndValidateTempDirectoryCreation();
    }

    @Test
    public void tempDirectoryExistsAsDirectoryWithFilesAndIsRecreatedAsEmptyDirectory()
            throws Exception {
        createTempDirectory();
        File createdFile = createFileNamed(TEMP_DIR_NAME + "/" + "junkfile");
        callAndValidateTempDirectoryCreation();
        createdFile.delete();
    }

    private File createFileNamed(String name) throws Exception {
        return FileUtilities.writeClassFile(new File("."), name, new byte[] {});
    }

    private void tempDirExistsAndIsDirectory() {
        File tempDirectory = new File(TEMP_DIR_NAME);
        assertTrue(tempDirectory.exists());
        assertTrue(tempDirectory.isDirectory());
    }

    private void createTempDirectory() {
        File tempDirectory = new File(TEMP_DIR_NAME);
        tempDirectory.mkdir();
    }

    private void callAndValidateTempDirectoryCreation() throws IOException {
        FileUtilities.createTemporaryDirectory(TEMP_DIR_NAME);
        tempDirExistsAndIsDirectory();
    }

}
