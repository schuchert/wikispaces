package schuchert.contest;

import static org.junit.Assert.assertEquals;

import java.util.Properties;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DynamicInstrumentorPropertiesTest {
    private static final String FOOBARBAZ = "foobarbaz";
    private Properties original;

    @Before
    public void recordSystemProperties() {
        original = (Properties) System.getProperties().clone();
    }

    @After
    public void restoreSystemProperties() {
        System.setProperties(original);
    }

    @Test
    public void canSetClassFilterProperty() {
        System.setProperty(DynamicInstrumentor.CON_TEST_INSTRUMENTATION_CLASS_FILTER, FOOBARBAZ);
        DynamicInstrumentor transformer = new DynamicInstrumentor();
        assertEquals(FOOBARBAZ, transformer.filterPatterns.get(0));
    }
}
