package schuchert.contest;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.ibm.contest.instrumentation.ClassStreamInstrumentor;
import com.ibm.contest.instrumentation.InstrumentationAction;

public class DynamicInstrumentor implements ClassFileTransformer {
    public static final String CON_TEST_INSTRUMENTATION_CLASS_FILTER = "schuchert.DI.classFilter";
    public static final String CON_TEST_INSTRUMENTATION_DELETE_FILES = "schuchert.DI.deleteFiles";

    List<String> filterPatterns = Collections.emptyList();

    public DynamicInstrumentor() {
        setDefaultClassFilter();
        processProperties();
    }

    private void setDefaultClassFilter() {
        setFilter("-com.*::-java.*::-org.*");
    }

    private void processProperties() {
        String property = System.getProperty(CON_TEST_INSTRUMENTATION_CLASS_FILTER);
        if (property != null)
            setFilter(property);
    }

    public byte[] transform(ClassLoader loader, String fullyQualifiedClassName,
            Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer)
            throws IllegalClassFormatException {

        if (isClassWeShouldProcess(fullyQualifiedClassName)) {
            ByteArrayInputStream inFile = new ByteArrayInputStream(classfileBuffer);
            ByteArrayOutputStream outFile = new ByteArrayOutputStream(4 * classfileBuffer.length);

            try {
                ClassStreamInstrumentor instrumentor = createInstrumentor(inFile,
                        fullyQualifiedClassName);
                instrumentor.instrumentInto(outFile, new InstrumentationAction(null, null));
                return outFile.toByteArray();
            } catch (Exception e) {
                e.printStackTrace(System.err);
            } finally {
                FileUtilities.closeIgnoringIoException(inFile);
                FileUtilities.closeIgnoringIoException(outFile);
            }
        }

        return null;
    }

    private ClassStreamInstrumentor createInstrumentor(InputStream classBytesFile, String className) {
        return new ClassStreamInstrumentor(classBytesFile, className, true);
    }

    boolean isClassWeShouldProcess(String fullyQualifiedClassname) {
        boolean noMatchingPatternResponse = true;

        for (String pattern : filterPatterns) {
            char operation = pattern.charAt(0);
            pattern = pattern.substring(1);
            switch (operation) {
            case '+':
                noMatchingPatternResponse = false;
                if (fullyQualifiedClassname.matches(pattern))
                    return true;
                break;
            case '-':
                if (fullyQualifiedClassname.matches(pattern))
                    return false;
                break;
            default:
                System.err.printf(
                        "Invalid pattern: %s for selecting classes to/to not instrument.", pattern);
            }
        }

        return noMatchingPatternResponse;
    }

    public void setFilter(String string) {
        String[] splitPatterns = null;

        if (string == null || string.trim().length() == 0)
            splitPatterns = new String[] {};
        else
            splitPatterns = string.split("::");

        filterPatterns = new ArrayList<String>();
        for (String currentString : splitPatterns) {
            if (currentString == null || currentString.trim().length() == 0)
                continue;
            filterPatterns.add(currentString.trim());
        }

    }
}
