package schuchert.contest;

import static junit.framework.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class DynamicInstrumentorFilterTest {
    DynamicInstrumentor transformer;
    private final String filter;
    private final boolean comShouldBeInstrumented;
    private final boolean javaShouldBeInstrumented;
    private final boolean schuchertShouldBeInstrumented;
    private final boolean fooShouldBeInstrumented;

    @Before
    public void setup() {
        transformer = new DynamicInstrumentor();
    }

    @Parameters
    public static Collection<Object[]> data() {
        ArrayList<Object[]> values = new ArrayList<Object[]>();
        values.add(new Object[] { "", true, true, true, true });
        values.add(new Object[] { "-java.*", true, false, true, true });
        values.add(new Object[] { "+java.*", false, true, false, false });
        values.add(new Object[] { "-java.*::-com.*", false, false, true, true });
        values.add(new Object[] { "+java.*::-schuchert.*::-com.*", false, true, false, false });
        values.add(new Object[] { "+[js].*", false, true, true, false });
        values.add(new Object[] { "+.*m$", true, false, false, false });
        return values;
    }

    public DynamicInstrumentorFilterTest(String filter,
            boolean matchComIbm, boolean matchJavaIo, boolean matchSchuchert, boolean matchFoo) {
        this.filter = filter;
        this.comShouldBeInstrumented = matchComIbm;
        this.javaShouldBeInstrumented = matchJavaIo;
        this.schuchertShouldBeInstrumented = matchSchuchert;
        this.fooShouldBeInstrumented = matchFoo;
    }

    @Test
    public void checkPattern() {
        transformer.setFilter(filter);
        assertFilterMatchedCorrectly("com/ibm", comShouldBeInstrumented);
        assertFilterMatchedCorrectly("java/io", javaShouldBeInstrumented);
        assertFilterMatchedCorrectly("schuchert/contest/", schuchertShouldBeInstrumented);
        assertFilterMatchedCorrectly("foo", fooShouldBeInstrumented);
    }

    private void assertFilterMatchedCorrectly(String string, boolean expected) {
        boolean result = transformer.isClassWeShouldProcess(string);
        assertEquals(String.format("Filter: %s, pattern: %s", filter, string), expected, result);

    }
}
