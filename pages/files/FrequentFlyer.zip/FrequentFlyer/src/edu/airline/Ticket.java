package edu.airline;

import java.util.*;

public class Ticket {

	private List<Segment> segments = new ArrayList<Segment>();

	public Ticket(Segment... segments) {
		this.segments = Arrays.asList(segments);
	}

	/** 
	 * Answer how many frequent flyer miles should
	 * be awarded for this ticket.
	 */
	public int getMilesFlown() {
		int milesFlown = 0;
		for(Segment segment : segments) {
			milesFlown += segment.getMilesFlown();
		}
		return milesFlown;
	}

	public List<Segment> getSegments() {
		return this.segments;
	}

}
