package edu.airline;


/**
 * A Segment is a part of a trip between two cities without the ability
 * to change planes.
 */
public class Segment {

	private boolean wasFlown;
	private int distance;

	public Segment(int distance) {
		this.distance = distance;
	}


	/**
	 * Answer how many miles a frequent flyer should accrue
	 * for me. 
	 * @return--the travel distance, or 0 if I haven't been flown yet.
	 */
	public int getMilesFlown() {
		if( wasFlown ) {
			return distance;
		}
		return 0;
	}


	public void wasFlown(boolean b) {
		wasFlown = b;
	}
	
	public boolean wasFlown() {
		return wasFlown;
	}

	public int getDistance() {
		return distance;
	}

}
