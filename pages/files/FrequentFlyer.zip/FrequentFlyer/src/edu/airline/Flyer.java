package edu.airline;

public class Flyer {


	private Ticket ticket;

	
	public int getMilesFlown() {
		if( ticket == null ) {
			return 0;
		}
		return ticket.getMilesFlown();
	}
	
	
	public void buys(Ticket ticket) {
		this.ticket = ticket;
	}
	
	
	/** 
	 * This method shows a more procedural
	 * implementation of  getMilesFlown.
	 */
	public int getMilesFlownAlternate() {
		if( ticket == null ) {
			return 0;
		}

		int milesFlown = 0;
		for(Segment segment : ticket.getSegments()) {
			int milesOnSegment = segment.wasFlown() ? segment.getDistance() : 0;
			milesFlown += milesOnSegment;
		}
		return milesFlown;
	}

}
