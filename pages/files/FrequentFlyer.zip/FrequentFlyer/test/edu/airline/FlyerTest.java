package edu.airline;

import junit.framework.TestCase;

public class FlyerTest extends TestCase {
	
	public void testInit() {
		Flyer flyer = new Flyer();
		assertEquals( 0, flyer.getMilesFlown());
	}


	public void testBuyOneSegment() {
		Flyer flyer = new Flyer();
		Segment segment = new Segment(1);
		Ticket ticket = new Ticket(segment);
		flyer.buys(ticket);
		assertEquals( 0, flyer.getMilesFlown());
	}
	
	public void testFlyOneSegment() {
		Flyer flyer = new Flyer();
		Segment segment = new Segment(1);
		Ticket ticket = new Ticket(segment);
		flyer.buys(ticket);
		segment.wasFlown(true);
		
		assertEquals( 1, flyer.getMilesFlown());
	}
	
	public void testFlyTwoSegments() {
		Flyer flyer = new Flyer();
		Segment segment1 = new Segment(1);
		Segment segment2 = new Segment(2);

		Ticket ticket = new Ticket(segment1, segment2);
		
		flyer.buys(ticket);
		for(Segment segment: ticket.getSegments()  ) {
			segment.wasFlown(true);
		}
		
		assertEquals( 3, flyer.getMilesFlown());
	}

}
