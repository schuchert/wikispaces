package vehicle.type;

public enum ValidationStatus {
	notValidated, valid, warning, invalidMissing, invalidIllformed, invalidRange, invalidInUse
}
