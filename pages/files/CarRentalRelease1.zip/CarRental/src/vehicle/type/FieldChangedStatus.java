package vehicle.type;

public enum FieldChangedStatus {
	unchanged, changed
}
