package vehicle.domain;

import java.io.Serializable;

public enum PhoneType implements Serializable, java.lang.Cloneable {
	primary, mobile, fax
}
