package vehicle.domain;

import java.io.Serializable;

public enum ValidState implements Serializable, java.lang.Cloneable {
	valid, invalid;
}
