package vehicle.domain;

import java.io.Serializable;

public enum AddressType implements Serializable {
	home, business, temporary
}
