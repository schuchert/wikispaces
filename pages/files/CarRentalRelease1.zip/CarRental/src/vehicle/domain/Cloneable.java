package vehicle.domain;

public interface Cloneable<T> extends java.lang.Cloneable {
	T clone();
}
