package loggingutil;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class LoggerImpl implements ILogger {
    private final Logger wrappedLogger; // NOPMD by brett.schuchert on 8/5/06
                                        // 5:58 PM

    public LoggerImpl(final Logger wrappedLogger) {
        this.wrappedLogger = wrappedLogger;
    }

    public ILogger debug(final String formatString, final Object... objects) {
        if (isDebugEnabled()) {
            wrappedLogger.debug(String.format(formatString, objects));
        }
        return this;
    }

    public ILogger debug(final Throwable t, final String formatString, final Object... objects) {
        if (isDebugEnabled()) {
            wrappedLogger.debug(String.format(formatString, objects), t);
        }
        return this;
    }

    public boolean isDebugEnabled() {
        return wrappedLogger.isDebugEnabled();
    }

    public ILogger warn(final String formatString, final Object... objects) {
        if (isWarnEnabled()) {
            wrappedLogger.warn(String.format(formatString, objects));
        }

        return this;
    }

    public ILogger warn(final Throwable t, final String formatString, final Object... objects) {
        if (isWarnEnabled()) {
            wrappedLogger.warn(String.format(formatString, objects), t);
        }

        return this;
    }

    public boolean isWarnEnabled() {
        return wrappedLogger.isEnabledFor(Level.WARN);
    }

    public ILogger info(final Throwable t, final String formatString, final Object... objects) {
        if (isInfoEnabled()) {
            wrappedLogger.info(String.format(formatString, objects));
        }

        return this;
    }

    public ILogger info(final String formatString, final Object... objects) {
        if (isInfoEnabled()) {
            wrappedLogger.info(String.format(formatString, objects));
        }

        return this;
    }

    public boolean isInfoEnabled() {
        return wrappedLogger.isEnabledFor(Level.INFO);
    }

    public ILogger error(final String formatString, final Object... objects) {
        if (isErrorEnabled()) {
            wrappedLogger.error(String.format(formatString, objects));
        }

        return this;
    }

    public ILogger error(final Throwable t, final String formatString, final Object... objects) {
        if (isErrorEnabled()) {
            wrappedLogger.error(String.format(formatString, objects), t);
        }

        return this;
    }

    public boolean isErrorEnabled() {
        return wrappedLogger.isEnabledFor(Level.ERROR);
    }

    public ILogger fatal(final String formatString, final Object... objects) {
        if (isFataEnabled()) {
            wrappedLogger.fatal(String.format(formatString, objects));
        }

        return this;
    }

    public ILogger fatal(final Throwable t, final String formatString, final Object... objects) {
        if (isFataEnabled()) {
            wrappedLogger.fatal(String.format(formatString, objects), t);
        }

        return this;
    }

    public boolean isFataEnabled() {
        return wrappedLogger.isEnabledFor(Level.FATAL);
    }

}
