package loggingutil;

import java.net.URL;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public final class LoggingConfiguration {
    private static final String LOG4J_PROPS = "loggingutil/log4j.properties";

    private LoggingConfiguration() {
        // utility class
    }

    static {
        BasicConfigurator.configure();
        URL propertiesUrl = LoggingConfiguration.class.getClassLoader().getResource(LOG4J_PROPS);
        if (propertiesUrl == null) {
            getLoggerFor(LoggingConfiguration.class).fatal(
                    String.format("Unable to configure logger using: %s", LOG4J_PROPS));
        } else {
            PropertyConfigurator.configure(propertiesUrl);
        }
    }

    public static ILogger getLoggerFor(final Class clazz) {
        return new LoggerImpl(Logger.getLogger(clazz));
    }

    public static void initialize() {
        // an empty method, when a class uses this method it causes the class
        // to get loaded, which runs its static initializer that reads
        // additional configuration.
    }

}
