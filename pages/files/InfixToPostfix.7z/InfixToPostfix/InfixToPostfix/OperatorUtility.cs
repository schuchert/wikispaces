﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace InfixToPostfix
{
  public class OperatorUtility
  {
    private Dictionary<string, int> _precedences = new Dictionary<string, int>();

    public OperatorUtility()
    {
      InstallOperatorPrecedence();
    }

    public bool LeftBeforeRight(string leftToken, string rightToken)
    {
      int pendingPrecedence = CalculatePrecedence(leftToken);
      int currentPrecedence = CalculatePrecedence(rightToken);

      return pendingPrecedence >= currentPrecedence;
    }

    public int CalculatePrecedence(string current)
    {
      if (_precedences.ContainsKey(current))
        return _precedences[current];
      throw new OperatorDoesNotExistException();
    }

    private void InstallOperatorPrecedence()
    {
      _precedences["*"] = 100;
      _precedences["/"] = 100;
      _precedences["+"] = 10;
      _precedences["-"] = 10;
      _precedences["="] = 5;
      _precedences["=="] = 3;
      _precedences["("] = -1;
      _precedences[")"] = -1;
    }

    public string[] GetAllOperators()
    {
      return (from s in _precedences.Keys orderby s.Length descending select s).ToArray();
    }
  }
}
