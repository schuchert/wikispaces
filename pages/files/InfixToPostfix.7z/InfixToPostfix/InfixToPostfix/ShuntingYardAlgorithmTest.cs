﻿using NUnit.Framework;

namespace InfixToPostfix
{
  [TestFixture]
  public class ShuntingYardAlgorithmTest
  {
    private string _result;

    [Test]
    public void EmptyExpressionResultsInSame()
    {
      Given("");
      Expect("");
    }

    [Test]
    public void NullExpressionProducesEmptyResult()
    {
      Given(null);
      Expect("");
    }

    [Test]
    public void JustANumberResultsInSame()
    {
      Given("42");
      Expect("42");
    }

    [Test]
    public void HandlesASingleBinaryOperator()
    {
      Given("4 + 2");
      Expect("4 2 +");
    }

    [Test]
    public void HandlesMultipleOperatorsOfSamePrecedence()
    {
      Given("a - 5 + 3");
      Expect("a 5 - 3 +");
    }

    [Test]
    public void HandlesMultiplePrecedences()
    {
      Given("a - 5 * 3");
      Expect("a 5 3 * -");
    }

    [Test]
    public void HandlesLowMediumHigh()
    {
      Given("q = a - 5 * 3");
      Expect("q a 5 3 * - =");
    }

    [Test]
    public void HandlesLowMediumHighLow()
    {
      Given("q = a - 5 * 3 + 4");
      Expect("q a 5 3 * - 4 + =");
    }

    [Test]
    public void RemovesUnnecessaryParentheses()
    {
      Given("( a * 3 ) + 4");
      Expect("a 3 * 4 +");
    }

    [Test]
    public void NecessaryParenthesesChangeOrderOfEvaluation()
    {
      Given("( 3 + 5 ) / 9");
      Expect("3 5 + 9 /");
    }

    [Test]
    public void HandlesUnnecesaryNestedParentheses()
    {
      Given("( ( 3 * 4 ) + 5 )");
      Expect("3 4 * 5 +");
    }

    [Test]
    public void HandlesNecessaryNestedParentheses()
    {
      Given("( ( a = 4 ) + 5 ) * 6");
      Expect("a 4 = 5 + 6 *");
    }

    [Test]
    public void HandlsBasicFunctionCall()
    {
      Given("f ( 3 )");
      Expect("3 f()");
    }

    [Test]
    public void HandlesFunctionsWithMultipleParameters()
    {
      Given("f ( 3 , 4 )");
      Expect("3 4 f()");
    }

    [Test]
    public void HandlesNestedFunctions()
    {
      Given("f ( 3 , g ( 4 , 1 ) )");
      Expect("3 4 1 g() f()");
    }

    [Test]
    public void HandlesOperatorsWithinParametersToFunctions()
    {
      Given("f ( 3 + 4 , 1 )");
      Expect("3 4 + 1 f()");
    }

    [Test]
    public void HandlesNestedFunctionsWithOperatorsInParameters()
    {
      Given("f ( 3 , g ( 4 + 5 , 1 ) )");
      Expect("3 4 5 + 1 g() f()");
    }

    [Test]
    public void UnderstandsIdentiy()
    {
      Given("a==b");
      Expect("a b ==");
    }

    private void Expect(string expected)
    {
      Assert.That(_result, Is.EqualTo(expected));
    }

    private void Given(string expression)
    {
      var algorithm = new ShuntingYardAlgorithm();
      _result = algorithm.Transform(expression);
    }
  }
}
