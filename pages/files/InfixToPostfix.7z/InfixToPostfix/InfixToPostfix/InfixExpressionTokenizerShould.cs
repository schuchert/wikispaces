﻿using System;
using NUnit.Framework;

namespace InfixToPostfix
{
  [TestFixture]
  class InfixExpressionTokenizerShould
  {
    private string _expression;

    [Test]
    public void ReturnNoTokensWhenGivenNull()
    {
      Given(null);
      Expect();
    }

    [Test]
    public void ReturnNoTokesnWhenGivenAnEmptyString()
    {
      Given("");
      Expect();
    }

    [Test]
    public void ParseABinaryOperatorWithNoSpaces()
    {
      Given("a+5");
      Expect("a", "+", "5");
    }

    [Test]
    public void HandleExtraSpaces()
    {
      Given("    a    +    5   ");
      Expect("a", "+", "5");
    }

    private void Expect(params string[] expected)
    {
      string[] result = new InfixExpressionTokenizer().Split(_expression);

      Assert.That(result, Is.EqualTo(expected));
    }

    private void Given(string expression)
    {
      _expression = expression;
    }
  }
}
