﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace InfixToPostfix
{
  class InfixExpressionTokenizer
  {
    private string _pattern;

    public InfixExpressionTokenizer()
    {
      _pattern = CreatePattern();
    }

    private string CreatePattern()
    {
      string pattern = @"(\w+|\d|,";
      string[] operators = new OperatorUtility().GetAllOperators();
      foreach (string operatorName in operators)
        pattern += String.Format(@"|{0}",EscapeEachCharacter(operatorName));

      return pattern + ")";
    }

    private string EscapeEachCharacter(string token)
    {
      return token.Aggregate("", (current, c) => current + String.Format(@"\{0}", c));
    }

    public string[] Split(string expression)
    {
      expression = (expression ?? "");

      Match matcher = Regex.Match(expression, _pattern);
      var tokens = new List<string>();

      while (matcher.Success)
      {
        tokens.Add(matcher.ToString());
        matcher = matcher.NextMatch();
      }

      return tokens.ToArray();
    }
  }
}
