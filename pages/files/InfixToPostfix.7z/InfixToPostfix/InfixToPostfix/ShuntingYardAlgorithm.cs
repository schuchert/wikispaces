using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace InfixToPostfix
{
  public class ShuntingYardAlgorithm
  {
    private Stack<String> _pendingTokens;
    private string[] _inputTokens;
    private List<String> _outputTokens;
    private OperatorUtility _operatorUtility = new OperatorUtility();

    public string Transform(string expression)
    {
      Initialize(expression);
      ProcessTokens();
      return ProductResult();
    }

    private string ProductResult()
    {
      string result = "";

      foreach (string current in _outputTokens)
      {
        if (result.Length > 0)
          result += " ";
        result += current;
      }

      return result;
    }

    private void ProcessTokens()
    {
      foreach (string current in _inputTokens)
        if (IsLiteral(current))
          HandleLiteral(current);
        else if (IsOpenParentheses(current))
          HandleOpenParentheses();
        else if (IsCloseParentheses(current))
          HandleCloseParentheses();
        else if (IsParameterSeperator(current))
          HandleParameterSeperator();
        else
          HandleOperator(current);

      AppendAllPendingTokens();
    }

    private void HandleParameterSeperator()
    {
      BalanceToOpenParentheses();
    }

    private bool IsParameterSeperator(string current)
    {
      return ",".Equals(current);
    }

    private bool IsOpenParentheses(string current)
    {
      return "(".Equals(current);
    }

    private void HandleOpenParentheses()
    {
      if (LastOutputTokenIsFunctionName())
        MoveLastOuputTokenToPendingTokens();
      AddToPendingTokens("(");
    }

    private void AddToPendingTokens(string token)
    {
      _pendingTokens.Push(token);
    }

    private void MoveLastOuputTokenToPendingTokens()
    {
      AddLastOutputTokenToPending();
      DropLastOutputToken();
    }

    private void AddLastOutputTokenToPending()
    {
      AddToPendingTokens(LastOutputToken());
    }

    private string LastOutputToken()
    {
      return _outputTokens[CalculateLastIndexOfOutputToken()];
    }

    private void DropLastOutputToken()
    {
      _outputTokens.RemoveAt(CalculateLastIndexOfOutputToken());
    }

    private int CalculateLastIndexOfOutputToken()
    {
      return _outputTokens.Count - 1;
    }

    private bool LastOutputTokenIsFunctionName()
    {
      return ThereAreOuputTokens() && IsFunctionName(LastOutputToken());
    }

    private bool ThereAreOuputTokens()
    {
      return _outputTokens.Count > 0;
    }

    private bool IsFunctionName(string token)
    {
      return Regex.IsMatch(token, @"\w+");
    }

    private bool IsCloseParentheses(string current)
    {
      return ")".Equals(current);
    }

    private void HandleCloseParentheses()
    {
      BalanceToOpenParentheses();
      DropOpenParentheses();
      ConditionallyAddFunctionNameToOuput();
    }

    private void ConditionallyAddFunctionNameToOuput()
    {
      if(LastPendingTokenIsFunctionName())
        AppendToken(BuildFunctionName());
    }

    private string BuildFunctionName()
    {
      return _pendingTokens.Pop() + "()";
    }

    private bool LastPendingTokenIsFunctionName()
    {
      return ThereArePendingTokens() && IsFunctionName(_pendingTokens.Peek());
    }

    private void DropOpenParentheses()
    {
      _pendingTokens.Pop();
    }

    private void BalanceToOpenParentheses()
    {
      while(LastPendingTokenIsNotOpenParenthess())
        AppendPendingToken();
    }

    private bool LastPendingTokenIsNotOpenParenthess()
    {
      return !_pendingTokens.Peek().Equals("(");
    }

    private void HandleLiteral(string current)
    {
      AppendToken(current);
    }

    private void AppendAllPendingTokens()
    {
      while(ThereArePendingTokens())
        AppendPendingToken();
    }

    private void AppendPendingToken()
    {
      AppendToken(_pendingTokens.Pop());
    }

    private bool ThereArePendingTokens()
    {
      return _pendingTokens.Count > 0;
    }

    private void HandleOperator(string current)
    {
      while(PendingTokenExecutesBefore(current))
        AppendPendingToken(); 

      AddToPendingTokens(current);
    }

    private bool PendingTokenExecutesBefore(string current)
    {
      if (ThereArePendingTokens())
        return _operatorUtility.LeftBeforeRight(_pendingTokens.Peek(), current);
      return false;
    }

    private void Initialize(string expression)
    {
      _pendingTokens = new Stack<String>();
      _inputTokens = new InfixExpressionTokenizer().Split(expression);
      _outputTokens = new List<String>();
    }

    private void AppendToken(string token)
    {
        _outputTokens.Add(token);
    }

    private bool IsLiteral(string token)
    {
      return Regex.IsMatch(token, @"(\w+|\d+)");
    }
  }
}