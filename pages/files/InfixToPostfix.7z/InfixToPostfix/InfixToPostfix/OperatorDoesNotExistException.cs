using System;

namespace InfixToPostfix
{
  public class OperatorDoesNotExistException : Exception
  {
  }
}