package com.om.characterization;

public class Site {
	public int kwh;
}
