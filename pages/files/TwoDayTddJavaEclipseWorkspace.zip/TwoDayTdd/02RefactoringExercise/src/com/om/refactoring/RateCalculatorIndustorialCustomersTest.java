package com.om.refactoring;

public class RateCalculatorIndustorialCustomersTest extends RateCalculatorBaseTest {

    protected void setUp() {
        super.setUp();
        customer.customerType = Customer.INDUSTRIAL;
    }

    public void testIndustiralWith0Sites0() {
        validateRate(0);
    }

    public void testIndustiralWith1Wit100Kwh() {
        addSite(100);
        validateRate(95);
    }
}
