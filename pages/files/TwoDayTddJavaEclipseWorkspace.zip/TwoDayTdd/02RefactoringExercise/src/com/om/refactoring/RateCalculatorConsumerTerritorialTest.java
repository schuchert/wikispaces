package com.om.refactoring;

public class RateCalculatorConsumerTerritorialTest extends RateCalculatorBaseTest {

    protected void setUp() {
        super.setUp();
        customer.customerType = Customer.CONSUMER;
        customer.rate = Customer.TERITORIAL;
        setKwh(500);
    }

    public void testTerritorial500KhWithAddressCategory1() {
        customer.address = 1;
        validateRate(30);
    }

    public void testTerritorial500KwhAddressCategory3() {
        customer.address = 3;
        validateRate(32.5);
    }
}
