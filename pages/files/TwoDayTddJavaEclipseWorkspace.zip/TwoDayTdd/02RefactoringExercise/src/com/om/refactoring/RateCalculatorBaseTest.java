package com.om.refactoring;

import junit.framework.TestCase;

public abstract class RateCalculatorBaseTest extends TestCase {
    RateCalculator rateCalculator;
    Customer customer;

    protected void setUp() {
        rateCalculator = new RateCalculator();
        customer = new Customer();
    }

    void validateRate(double expectedRate) {
        double actualRate = rateCalculator.calculateRate(customer);
        assertEquals(expectedRate, actualRate, 0.0001);
    }

    protected void addSite(int kwh) {
        Site site = new Site();
        site.kwh = kwh;
        customer.sites.add(site);
    }

    void setKwh(int kwh) {
        customer.kwh = kwh;
    }
}
