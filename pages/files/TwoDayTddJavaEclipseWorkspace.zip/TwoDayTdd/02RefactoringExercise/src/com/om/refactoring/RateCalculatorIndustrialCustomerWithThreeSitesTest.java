package com.om.refactoring;

public class RateCalculatorIndustrialCustomerWithThreeSitesTest extends RateCalculatorBaseTest {

    protected void setUp() {
        super.setUp();
        customer.customerType = Customer.INDUSTRIAL;
        addSite(300);
        addSite(600);
        addSite(9700);
    }

    public void testIndustiralWith3SitesVariableKwh() {
        validateRate(10070);
    }

    public void testIndustrialInterruptable() {
        customer.industrialRate = Customer.INTERRUPTABLE;
        validateRate(8480);
    }

    public void testIndustrialOneHourNotice() {
        customer.industrialRate = Customer.ONE_HOUR_NOTICE;
        validateRate(9540);
    }

    public void testIndustrialDefault() {
        customer.industrialRate = Customer.UNDEFINED;
        validateRate(10070);
    }
}
