package com.om.switchtopolymorphism;

public class RateCalculatorEmptyCustomerTest extends RateCalculatorBaseTest {
    public void testBlankCustomerHas0Rate() {
        validateRate(0);
    }
}
