package com.om.switchtopolymorphism;

public class RateCalculatorLifelineCustomerTest extends RateCalculatorEmptyCustomerTest {

    protected void setUp() {
        super.setUp();
        customer.address = 1;
        customer.customerType = Customer.CONSUMER;
        customer.rate = Customer.LIFELINE;
        
    }
    
    public void testLifeline200Kwh() {
        setKwh(200);
        validateRate(8);
    }
    
    public void testLifeline100Kwh() {
        setKwh(100);
        validateRate(3);
    }
    
    public void testLifeline500KwhSameAsTerritorial() {
        setKwh(500);
        validateRate(30);
    }
}
