package ex2;

public class Main {
    public static void main(String[] args) {
        Address address = new Address();
        address.setAddressLine1("5080 Spectrum Drive");
        address.setAddressLine2("Suite 700 West");
        address.setCity("Dallas");
        address.setState("TX");
        address.setZip("75001");
        address.setZip("75001");
    }
}
