package varargs.v1;

import org.apache.log4j.Logger;

public final class Main {
    private Main() {
        // all static methods, do not instantiate me
    }

    public static final String FILE_NAME = "SomeFileName";
    public static final String ERROR_CONTACT = "someemail@palcetocontact.com";

    public static void main(final String[] args) {
        final Logger myLogger = LoggingConfiguration.getLoggerFor(Main.class);

        myLogger.debug("Problem with file: " + FILE_NAME + ". Please contact: " + ERROR_CONTACT);
    }
}
