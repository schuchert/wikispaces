package varargs.v4;

public final class Main {
    private Main() {
        // all static methods, do not instantiate me
    }

    public static final String FILE_NAME = "SomeFileName";
    public static final String ERROR_CONTACT = "someemail@palcetocontact.com";

    public static void main(final String[] args) {
        final ILogger myLogger = LoggingConfiguration.getLoggerFor(Main.class);

        myLogger.debug("Problem with file: %s. Please contact: %s", FILE_NAME, ERROR_CONTACT);
    }
}
