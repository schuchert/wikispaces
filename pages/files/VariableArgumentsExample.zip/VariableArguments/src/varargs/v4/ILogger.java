package varargs.v4;

public interface ILogger {
    ILogger debug(String formatString, Object... objects);
    ILogger debug(Throwable t, String formatString, Object... objects);
    boolean isDebugEnabled();

    ILogger info(String formatString, Object... objects);
    ILogger info(Throwable t, String formatString, Object... objects);
    boolean isInfoEnabled();

    ILogger warn(String formatString, Object... objects);
    ILogger warn(Throwable t, String formatString, Object... objects);
    boolean isWarnEnabled();

    ILogger error(String formatString, Object... objects);
    ILogger error(Throwable t, String formatString, Object... objects);
    boolean isErrorEnabled();

    ILogger fatal(String formatString, Object... objects);
    ILogger fatal(Throwable t, String formatString, Object... objects);
    boolean isFataEnabled();
}
