Component Coupling

the objective 
 * to decide how to decouple the web packages from the library

Look at the jdepend_report.png
Are the interpackage dependencies going towards abstractions? 
Do they form a DAG? Are they pointing at packages more stable than themselves?

The web packages should not know about the library
  Rename of the all the ...library.web... to ...web..
  Search the web packages for com.objectmentor.library
  Investigate how to cut those dependencies.

Using these principles as a guide, define changes needed to
extract the web framework.

When you are done, this framework should have no dependencies
on the rest of the library code.
 * To get warmed up, start with a package with very few dependencies
 * The tackle the more difficult cases.

NOTE: this will require more than simply moving files around.  
Some new abstractions and packages will be needed.

