package ex2;

public class Main {
	public static void main(String args[]) {
		Address a = new Address();
		a.setAddressLine1("5080 Spectrum Drive");
		a.setAddressLine2("Suite 700 West");
		a.setCity("Dallas");
		a.setState("TX");
		a.setZip("75001");
		a.setZip("75001");
	}
}
