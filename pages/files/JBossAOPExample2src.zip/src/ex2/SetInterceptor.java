package ex2;

import java.lang.reflect.Field;

import org.jboss.aop.advice.Interceptor;
import org.jboss.aop.joinpoint.FieldWriteInvocation;
import org.jboss.aop.joinpoint.Invocation;

public class SetInterceptor implements Interceptor {
	public String getName() {
		return "SetInterceptor";
	}

	public Object invoke(Invocation invocation) throws Throwable {
		if (!(invocation instanceof FieldWriteInvocation))
			return invocation.invokeNext();

		FieldWriteInvocation mi = (FieldWriteInvocation) invocation;
		Object newValue = mi.getValue();
		Object target = mi.getTargetObject();
		Field field = mi.getField();
		Object currentValue = field.get(target);

		System.out.printf("Setting %s from %s to %s\n", field.getName(),
				currentValue, newValue);
		return invocation.invokeNext();
	}
}
