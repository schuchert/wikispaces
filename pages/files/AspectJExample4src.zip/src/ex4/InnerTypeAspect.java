package ex4;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.DeclareParents;

@Aspect
public class InnerTypeAspect {
    @DeclareParents(value = "ex4.Address", defaultImpl = ex4.TrackedObjectMixin.class)
    ITrackedObject trackedObject;
}
