package ex4;

import java.lang.reflect.Field;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.FieldSignature;

@Aspect
public class FieldSetAspect {
    @Pointcut("!set(* ex4.TrackedObjectMixin.*)")
    public void skipTrackedObject() {
    }

    @Pointcut("args(rhs) && set(* ex4.Address.*)")
    public void allFields(Object rhs) {
    }

    @Around("allFields(rhs) && skipTrackedObject()")
    public Object trackFieldAssignment(ProceedingJoinPoint thisJoinPoint,
            Object rhs) throws Throwable {
        FieldSignature fs = (FieldSignature) thisJoinPoint.getSignature();

        Object target = thisJoinPoint.getTarget();
        Field field = fs.getField();
        field.setAccessible(true);
        Object currentValue = field.get(target);

        if (equals(currentValue, rhs)) {
            return null;
        } else {
            ((ITrackedObject) target).setChanged(true);
            return thisJoinPoint.proceed();
        }
    }

    private boolean equals(Object lhs, Object rhs) {
        if (lhs == null && rhs == null) {
            return true;
        }
        if (lhs == null && rhs != null) {
            return false;
        }
        if (lhs != null && rhs == null) {
            return false;
        }
        return lhs.equals(rhs);
    }
}