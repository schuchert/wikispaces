package ex4;

public class Main {
    public static void main(String args[]) {
        Address a = new Address();
        Dao.save(a);
        a.setZip(null);
        Dao.save(a);
        a.setZip("75001");
        Dao.save(a);
        Dao.save(a);
    }
}
