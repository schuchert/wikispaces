package ex4;

public class Dao {
    public static void save(Object o) {
        if (o != null) {
            System.out.printf("Saving: %s\n", o.getClass());
        }
    }
}
