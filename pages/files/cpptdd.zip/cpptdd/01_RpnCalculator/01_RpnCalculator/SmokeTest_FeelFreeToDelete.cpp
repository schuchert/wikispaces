#include <CppUTest/TestHarness.h>
 
TEST_GROUP(ATestGroup)
{
};
 
TEST(ATestGroup, Work) {
  LONGS_EQUAL(1, 1);
}