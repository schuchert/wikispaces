#include "CppUTest/TestHarness.h"

TEST_GROUP(ProjectNeedsTests)
{
  void setup()
  {
  }
  void teardown()
  {
  }
};

TEST(ProjectNeedsTests, Create)
{
  FAIL("Project needs some tests");
}

