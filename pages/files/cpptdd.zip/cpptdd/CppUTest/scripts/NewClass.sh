#!/bin/bash
TEMPLATE_DIR=${CPP_U_TEST}/scripts/templates
source ${CPP_U_TEST}/scripts/GenerateSrcFiles.sh ClassName cpp NoMock $1 $2

