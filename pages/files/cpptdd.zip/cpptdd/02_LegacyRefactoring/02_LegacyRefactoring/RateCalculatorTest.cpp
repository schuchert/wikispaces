#include <CppUTest/TestHarness.h>
#include "RateCalculator.hpp"
#include "Customer.hpp"
#include "Site.hpp"

TEST_GROUP(RateCalculator) {
  RateCalculator *calculator;
  Customer *customer;

  virtual void setup() {
    calculator = new RateCalculator();
    customer = new Customer();
  }

  virtual void teardown() {
    delete customer;
    delete calculator;
  }
};

TEST(RateCalculator, DefaultRate0) {
  double result = calculator->calculateRate(*customer);
  CHECK_EQUAL(0, result);
}