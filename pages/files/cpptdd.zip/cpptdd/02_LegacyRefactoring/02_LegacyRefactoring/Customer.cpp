#include "Customer.hpp"

#include "Site.hpp"

Customer::~Customer() {
	for(c_site::iterator iter = sites.begin(); iter != sites.end(); ++iter) {
		delete  *iter;
	}
}
