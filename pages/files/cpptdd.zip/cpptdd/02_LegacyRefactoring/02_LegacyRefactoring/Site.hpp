#ifndef SITE_H
#define SITE_H

struct Site {
	int kwh;
};

#endif
