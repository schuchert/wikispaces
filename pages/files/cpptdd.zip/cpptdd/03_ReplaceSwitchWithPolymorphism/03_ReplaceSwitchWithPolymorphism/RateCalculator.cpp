#include "RateCalculator.hpp"
#include "Customer.hpp"
#include "Site.hpp"

double RateCalculator::calculateRate(Customer &customer) {
	switch(customer.type) {
		case consumer:
			return calculateConsumerRate(customer);
		case business:
			return calculateBusinessRate(customer);
		case industrial:
			return calculateIndustrialRate(customer);
		default:
			return 0;
	}
}

double RateCalculator::calculateConsumerRate(Customer &customer) {
	if(customerIsEligibleForLifelineRate(customer)) {
		return calculateLifelineRate(customer);
	}

	return calculateTerritorialRate(customer);
}

bool RateCalculator::customerIsEligibleForLifelineRate(Customer &customer) {
	return customer.rate == lifeline && customer.kwh <= 200;
}

double RateCalculator::calculateLifelineRate(Customer &customer) {
	int tier2Kwh = std::max(customer.kwh - 100, 0);
	int tier1Kwh = customer.kwh - tier2Kwh;
	return tier1Kwh *0.03 + tier2Kwh * 0.05;
}

double RateCalculator::calculateTerritorialRate(Customer &customer) {
	switch(calculateTerritory(customer.address)) {
		case 1:
			// spec says territory 1 and 2 use same rate.
		case 2:
			return customer.kwh *(isWinter() ? .07 : .06);
		case 3:
			return customer.kwh *.065;
	}
}

int RateCalculator::calculateTerritory(int address) {
	return address;
}

bool RateCalculator::isWinter() {
	return false;
}

double RateCalculator::calculateBusinessRate(Customer &customer) {
	double rate = 0;

	for(Customer::c_site::iterator i = customer.sites.begin(); i != customer.sites.end(); ++i) {
		Site *s =  *i;
		rate += calculateSlidingScale(s->kwh);
	}

	return rate;
}

int RateCalculator::calculateSlidingScale(int kwh) {
	return kwh;
}

double RateCalculator::calculateIndustrialRate(Customer &customer) {
	double businessRate = calculateBusinessRate(customer);
	double industrialRateModifier = calculateIndustrialRateModifier(customer);
	return businessRate *industrialRateModifier;
}

double RateCalculator::calculateIndustrialRateModifier(Customer &customer) {
	switch(customer.industrialRate) {
		case interruptable:
			return .8;
		case oneHourNotice:
			return .9;
		default:
			return .95;
	}
}
