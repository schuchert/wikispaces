#ifndef RateCalculator_HPP
#define RateCalculator_HPP

struct Customer;

class RateCalculator {
public:
	double calculateRate(Customer &customer);

private:
	double calculateIndustrialRate(Customer &customer);
	double calculateBusinessRate(Customer &customer);
	double calculateConsumerRate(Customer &customer);
	double calculateLifelineRate(Customer &customer);
	bool customerIsEligibleForLifelineRate(Customer &customer);
	double calculateTerritorialRate(Customer &customer);
	double RateCalculator::calculateIndustrialRateModifier(Customer &customer);
	bool isWinter();
	int calculateSlidingScale(int kwh);
	int calculateTerritory(int address);
};

#endif
