package session;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityNotFoundException;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import util.DateTimeUtil;
import entity.Address;
import entity.Author;
import entity.Book;
import entity.Dvd;
import entity.Name;
import entity.Patron;
import entity.Resource;
import exception.InsufficientFunds;
import exception.PatronHasFines;
import exception.ResourceAlreadyCheckedOut;
import exception.ResourceNotCheckedOut;

public class LibraryTest extends EntityManagerBasedTest {
    private static final long ID_DNE = -443123222l;
    private static final String PATRON_ID = "113322";
    private static final String ISBN = "1-932394-15-X";
    private static Date CURRENT_DATE;
    private static Date CURRENT_PLUS_6;
    private static Date CURRENT_PLUS_8;
    private static Date CURRENT_PLUS_14;
    private static Date CURRENT_PLUS_15;
    private Library library;

    @Before
    public void setupLibrary() {
        final ResourceDao rd = new ResourceDao();
        rd.setEm(getEm());
        final PatronDao pd = new PatronDao();
        pd.setEm(getEm());
        final LoanDao ld = new LoanDao();
        ld.setEm(getEm());
        final BookDao bd = new BookDao();

        library = new Library();
        library.setResourceDao(rd);
        library.setPatronDao(pd);
        library.setLoanDao(ld);
        library.setBookDao(bd);
    }

    @BeforeClass
    public static void setupDates() {
        Calendar c = Calendar.getInstance();
        DateTimeUtil.removeTimeFrom(c);
        CURRENT_DATE = c.getTime();
        c.add(Calendar.DAY_OF_MONTH, 6);
        CURRENT_PLUS_6 = c.getTime();
        c.add(Calendar.DAY_OF_MONTH, 2);
        CURRENT_PLUS_8 = c.getTime();
        c.add(Calendar.DAY_OF_MONTH, 6);
        CURRENT_PLUS_14 = c.getTime();
        c.add(Calendar.DAY_OF_MONTH, 1);
        CURRENT_PLUS_15 = c.getTime();
    }

    @Test
    public void addBook() {
        final Book b = createBook();
        final Set<Author> authors = b.getAuthors();
        final Resource found = library.findResourceById(b.getId());

        assertTrue(found instanceof Book);
        assertTrue(((Book) found).getAuthors().containsAll(authors));
    }

    @Test(expected = EntityNotFoundException.class)
    public void lookupBookThatDoesNotExist() {
        library.findResourceById(ID_DNE);
    }

    @Test
    public void addPatron() {
        final Patron p = createPatron();
        final Patron found = library.findPatronById(p.getId());
        assertNotNull(found);
    }

    @Test(expected = EntityNotFoundException.class)
    public void lookupPatronThatDoesNotExist() {
        library.findPatronById(ID_DNE);
    }

    @Test
    public void checkoutBook() {
        final Book b1 = createBook();
        final Book b2 = createBook();
        final Patron p = createPatron();
        library.checkout(p.getId(), CURRENT_DATE, b1.getId(), b2.getId());

        final List<Resource> list = library.listResourcesOnLoanTo(p.getId());

        assertEquals(2, list.size());

        for (Resource r : list) {
            assertTrue(r.isOnLoanTo(p));
            assertTrue(r.dueDateEquals(CURRENT_PLUS_14));
        }
    }

    @Test
    public void returnBook() {
        final Book b = createBook();
        final Patron p = createPatron();
        library.checkout(p.getId(), CURRENT_DATE, b.getId());

        final int resourcesBefore = p.getCheckedOutResources().size();
        assertTrue(b.isCheckedOut());
        library.returnResource(CURRENT_PLUS_8, b.getId());
        assertEquals(resourcesBefore - 1, p.getCheckedOutResources().size());
        assertFalse(b.isCheckedOut());
        assertEquals(0, p.getFines().size());
    }

    @Test
    public void returnResourceLate() {
        final Book b = createBook();
        final Patron p = createPatron();

        library.checkout(p.getId(), CURRENT_DATE, b.getId());
        library.returnResource(CURRENT_PLUS_15, b.getId());

        assertEquals(1, p.getFines().size());
        assertEquals(.25, p.calculateTotalFines());
    }

    @Test(expected = ResourceNotCheckedOut.class)
    public void returnResourceThatsNotCheckedOut() {
        final Book b = createBook();
        assertFalse(b.isCheckedOut());
        library.returnResource(CURRENT_PLUS_8, b.getId());
    }

    @Test(expected = ResourceAlreadyCheckedOut.class)
    public void checkoutBookThatIsAlreadyCheckedOut() {
        final Book b = createBook();
        final Patron p1 = createPatron();
        final Patron p2 = createPatron();

        library.checkout(p1.getId(), CURRENT_DATE, b.getId());
        library.checkout(p2.getId(), CURRENT_DATE, b.getId());
    }

    @Test(expected = EntityNotFoundException.class)
    public void checkoutBookThatDoesNotExist() {
        final Patron p = createPatron();
        library.checkout(p.getId(), CURRENT_DATE, ID_DNE);
    }

    @Test(expected = EntityNotFoundException.class)
    public void checkoutBookToPatronThatDoesNotExist() {
        final Book b = createBook();
        library.checkout(ID_DNE, CURRENT_DATE, b.getId());
    }

    @Test
    public void findOverdueBooks() {
        final Patron p = createPatron();
        final Book b1 = createBook();
        final Book b2 = createBook();
        library.checkout(p.getId(), CURRENT_DATE, b1.getId());
        library.checkout(p.getId(), CURRENT_PLUS_8, b2.getId());
        final List<Resource> notOverdue = library
                .findAllOverdueResources(CURRENT_PLUS_8);
        assertEquals(0, notOverdue.size());
        final List<Resource> overdue = library
                .findAllOverdueResources(CURRENT_PLUS_15);
        assertEquals(1, overdue.size());
        assertTrue(overdue.contains(b1));
    }

    @Test
    public void patronsWithOverdueBooks() {
        final Patron p = createPatron();
        final Book b1 = createBook();
        final Book b2 = createBook();
        library.checkout(p.getId(), CURRENT_DATE, b1.getId());
        library.checkout(p.getId(), CURRENT_PLUS_8, b2.getId());
        final List<Patron> noPatrons = library
                .findAllPatronsWithOverdueBooks(CURRENT_PLUS_14);
        assertEquals(0, noPatrons.size());
        final List<Patron> onePatron = library
                .findAllPatronsWithOverdueBooks(CURRENT_PLUS_15);
        assertEquals(1, onePatron.size());
    }

    @Test
    public void calculateTotalFinesForPatron() {
        final Patron p = createPatron();
        final Book b1 = createBook();
        final Book b2 = createBook();
        library.checkout(p.getId(), CURRENT_DATE, b1.getId());
        library.checkout(p.getId(), CURRENT_DATE, b2.getId());
        library.returnResource(CURRENT_PLUS_15, b1.getId(), b2.getId());
        assertEquals(.5, library.calculateTotalFinesFor(p.getId()));
    }

    @Test
    public void payFineExactAmount() {
        final Patron p = createPatron();
        final Book b1 = createBook();
        library.checkout(p.getId(), CURRENT_DATE, b1.getId());
        library.returnResource(CURRENT_PLUS_15, b1.getId());
        double change = library.tenderFine(p.getId(), .25);
        assertEquals(0d, change);
        assertEquals(0, p.getFines().size());
    }

    @Test(expected = InsufficientFunds.class)
    public void payFineInsufficientFunds() {
        final Patron p = createPatron();
        final Book b1 = createBook();
        library.checkout(p.getId(), CURRENT_DATE, b1.getId());
        library.returnResource(CURRENT_PLUS_15, b1.getId());
        library.tenderFine(p.getId(), .20);
    }

    /**
     * This is an example of a test where we expect an exception. However,
     * unlike other tests where we use expected=ExceptionClass.class, we need to
     * catch the exception because we are additionally verifying a value in the
     * thrown exception. This test is written how you'd write a test expecting
     * an exception prior to JUnit 4.
     */
    @Test
    public void patronCannotCheckoutWithFines() {
        final Patron p = createPatron();
        final Book b1 = createBook();
        library.checkout(p.getId(), CURRENT_DATE, b1.getId());
        library.returnResource(CURRENT_PLUS_15, b1.getId());

        final Book b2 = createBook();

        try {
            library.checkout(p.getId(), CURRENT_DATE, b2.getId());
            fail(String.format("Should have thrown exception: %s",
                    PatronHasFines.class.getName()));
        } catch (PatronHasFines e) {
            assertEquals(.25, e.getTotalFines());
        }
    }

    @Test
    public void checkoutDvd() {
        final Patron p = createPatron();
        final Dvd d = createDvd();
        library.checkout(p.getId(), CURRENT_DATE, d.getId());
        assertTrue(d.isOnLoanTo(p));
        assertEquals(CURRENT_PLUS_6, d.getDueDate());
    }

    @Test
    public void returnDvdLate() {
        final Dvd d = createDvd();
        final Patron p = createPatron();

        library.checkout(p.getId(), CURRENT_DATE, d.getId());
        library.returnResource(CURRENT_PLUS_8, d.getId());

        assertEquals(1, p.getFines().size());
        assertEquals(0.6d, p.calculateTotalFines());
    }
    
    @Test
    public void checkoutDvdAndBook() {
        final Dvd d = createDvd();
        final Book b = createBook();
        final Patron p = createPatron();
        
        library.checkout(p.getId(), CURRENT_DATE, d.getId());
        library.checkout(p.getId(), CURRENT_DATE, b.getId());
        
        final List<Resource> list = library.listResourcesOnLoanTo(p.getId());
        assertEquals(2, list.size());
        assertTrue(d.isOnLoanTo(p));
        assertTrue(b.isOnLoanTo(p));
    }

    private Book createBook() {
        final Author a1 = new Author(new Name("Christian", "Bauer"));
        final Author a2 = new Author(new Name("Gavin", "King"));

        return library.createBook("Hibernate In Action", ISBN, Calendar
                .getInstance().getTime(), a1, a2);
    }

    private Patron createPatron() {
        final Address a = new Address("5080 Spectrum Drive", "", "Dallas",
                "TX", "75001");
        return library.createPatron(PATRON_ID, "Brett", "Schuchert",
                "555-1212", a);
    }

    private Dvd createDvd() {
        return library.createDvd("Raiders of the Lost Ark", new Name("Steven",
                "Spielberg"));
    }
}