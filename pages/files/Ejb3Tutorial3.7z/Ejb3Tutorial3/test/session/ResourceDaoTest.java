package session;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Calendar;

import org.junit.Test;

import entity.Author;
import entity.Book;
import entity.Name;
import entity.Resource;

public class ResourceDaoTest extends BaseDbDaoTest {
    private ResourceDao dao;

    /**
     * By overriding this method, I'm able to provide a dao to the base class,
     * which then installs a new entity manager per test method execution. Note
     * that my return type is not the same as the base class' version. I return
     * BookDao whereas the base class returns BaseDao. Normally an overridden
     * method must return the same type. However, it is OK for an overridden
     * method to return a different type so long as that different type is a
     * subclass of the type returned in the base class. This is called
     * covariance.
     * 
     * @see session.BaseDbDaoTest#getDao()
     */

    @Override
    public ResourceDao getDao() {
        if (dao == null) {
            dao = new ResourceDao();
        }
        return dao;
    }

    @Test
    public void createABook() {
        final Book b = createABookImpl();
        final Resource found = getDao().retrieve(b.getId());
        assertNotNull(found);

    }

    private Book createABookImpl() {
        final Author a1 = new Author(new Name("Bill", "Burke"));
        final Author a2 = new Author(new Name("Richard", "Monson-Haefel"));
        final Book b = new Book("Enterprise JavaBeans 3.0",
                "978-0-596-00978-6", Calendar.getInstance().getTime(), a1, a2);
        getDao().create(b);

        return b;
    }

    @Test
    public void removeABook() {
        final Book b = createABookImpl();
        Resource found = getDao().retrieve(b.getId());
        assertNotNull(found);
        getDao().remove(b.getId());
        found = getDao().retrieve(b.getId());
        assertNull(found);
    }

    @Test
    public void updateABook() {
        final Book b = createABookImpl();
        final int initialAuthorCount = b.getAuthors().size();
        b.addAuthor(new Author(new Name("New", "Author")));
        getDao().update(b);
        final Resource found = getDao().retrieve(b.getId());
        assertTrue(found instanceof Book);
        assertEquals(initialAuthorCount + 1, ((Book) found).getAuthors().size());
    }

    @Test
    public void tryToFindBookThatDoesNotExist() {
        final Resource r = getDao().retrieve(-1123123123l);
        assertNull(r);
    }
}
