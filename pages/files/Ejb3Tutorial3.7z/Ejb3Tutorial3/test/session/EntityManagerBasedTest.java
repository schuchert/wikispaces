package session;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

/**
 * Our tests use an entity manager. The first pass at the BaseDbDaoTest forced
 * initialization of a Dao. That works for the dao-based tests but not all
 * tests. This class factors out just the part that sets up and cleans up the
 * entity manager.
 * 
 */
public abstract class EntityManagerBasedTest {
	private static EntityManagerFactory emf;

	private EntityManager em;

	/**
	 * Once before the tests start running for a given class, init the logger
	 * with a basic configuration and set the default reporting layer to error
	 * for all classes whose package starts with org.
	 */
	@BeforeClass
	public static void initLogger() {
		// Produce minimal output.
		BasicConfigurator.configure();

		// Comment this line to see a lot of initialization
		// status logging.
		Logger.getLogger("org").setLevel(Level.ERROR);
		Logger.getLogger("net").setLevel(Level.ERROR);
	}

	@BeforeClass
	public static void initEmf() {
		emf = Persistence.createEntityManagerFactory("lis");
	}

	@AfterClass
	public static void closeEmf() {
		emf.close();
	}

	/**
	 * Before each test method, look up the entity manager factory, then create
	 * the entity manager.
	 */
	@Before
	public void initEmfAndEm() {
		em = emf.createEntityManager();
		em.getTransaction().begin();
	}

	/**
	 * After each test method, roll back the transaction started in the -at-
	 * Before method then close both the entity manager and entity manager
	 * factory.
	 */
	@After
	public void closeEmAndEmf() {
		getEm().getTransaction().rollback();
		getEm().close();
	}

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}
}
