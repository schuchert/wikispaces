package session;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import entity.Address;
import entity.Author;
import entity.Book;
import entity.Director;
import entity.Dvd;
import entity.Loan;
import entity.Name;
import entity.Patron;
import entity.Resource;
import exception.PatronHasFines;
import exception.ResourceAlreadyCheckedOut;
import exception.ResourceNotCheckedOut;

/**
 * This class provides a basic facade to the library system. If we had a user
 * interface, it would interact with this object rather than dealing with all of
 * the underlying Daos.
 */
public class Library {
    private ResourceDao resourceDao;
    private BookDao bookDao;
    private PatronDao patronDao;
    private LoanDao loanDao;

    public ResourceDao getResourceDao() {
        return resourceDao;
    }

    public void setResourceDao(final ResourceDao bookDao) {
        this.resourceDao = bookDao;
    }

    public PatronDao getPatronDao() {
        return patronDao;
    }

    public void setPatronDao(final PatronDao patronDao) {
        this.patronDao = patronDao;
    }

    public LoanDao getLoanDao() {
        return loanDao;
    }

    public void setLoanDao(final LoanDao loanDao) {
        this.loanDao = loanDao;
    }

    public BookDao getBookDao() {
        return bookDao;
    }

    public void setBookDao(BookDao bookDao) {
        this.bookDao = bookDao;
    }

    public Book createBook(final String title, final String isbn,
            final Date date, final Author a1, final Author a2) {
        final Book b = new Book(title, isbn, date, a1, a2);

        getResourceDao().create(b);

        return b;
    }

    public List<Book> findBookByIsbn(String isbn) {
        return getBookDao().findByIsbn(isbn);
    }

    public Patron createPatron(final String patronId, final String fname,
            final String lname, final String phoneNumber, final Address a) {
        return getPatronDao().createPatron(fname, lname, phoneNumber, a);
    }

    public Patron findPatronById(final Long id) {
        final Patron p = getPatronDao().retrieve(id);
        if (p == null) {
            throw new EntityNotFoundException(String.format(
                    "Patron with id: %d does not exist", id));
        }
        return p;
    }

    public Resource findResourceById(Long id) {
        final Resource r = getResourceDao().findById(id);
        if (r == null) {
            throw new EntityNotFoundException(String.format(
                    "Book with Id:%d does not exist", id));
        }
        return r;
    }

    public void returnResource(final Date checkinDate,
            final Long... resourceIds) {
        for (Long resourceId : resourceIds) {
            final Loan l = getLoanDao().getLoanFor(resourceId);

            if (l == null) {
                throw new ResourceNotCheckedOut(resourceId);
            }

            l.checkin(checkinDate);

            getLoanDao().remove(l);
        }
    }

    public void checkout(final Long patronId, final Date checkoutDate,
            final Long... resourceIds) {
        final Patron p = findPatronById(patronId);

        double totalFines = p.calculateTotalFines();

        if (totalFines > 0.0d) {
            throw new PatronHasFines(totalFines);
        }

        for (Long id : resourceIds) {
            final Resource r = findResourceById(id);

            if (r.isCheckedOut()) {
                throw new ResourceAlreadyCheckedOut(id);
            }

            p.checkout(r, checkoutDate);
        }
    }

    public List<Resource> listResourcesOnLoanTo(final Long patronId) {
        return getLoanDao().listResourcesOnLoanTo(patronId);
    }

    public List<Resource> findAllOverdueResources(final Date compareDate) {
        return getLoanDao().listAllOverdueResources(compareDate);
    }

    public List<Patron> findAllPatronsWithOverdueBooks(final Date compareDate) {
        return getLoanDao().listAllPatronsWithOverdueResources(compareDate);
    }

    public double calculateTotalFinesFor(final Long patronId) {
        return getPatronDao().retrieve(patronId).calculateTotalFines();
    }

    public double tenderFine(final Long patronId, double amountTendered) {
        final Patron p = getPatronDao().retrieve(patronId);
        return p.pay(amountTendered);
    }

    public Dvd createDvd(final String title, final Name directorsName) {
        final Director director = new Director();
        director.setName(directorsName);
        final Dvd d = new Dvd();
        d.setTitle(title);
        d.setDirector(director);
        getResourceDao().create(d);
        return d;
    }
}
