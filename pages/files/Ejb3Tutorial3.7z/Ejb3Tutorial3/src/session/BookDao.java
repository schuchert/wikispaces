package session;

import java.util.List;

import entity.Book;

public class BookDao extends BaseDao {

    @SuppressWarnings("unchecked")
    public List<Book> findByIsbn(final String isbn) {
        return getEm().createNamedQuery("Book.findByIsbn").setParameter("isbn",
                isbn).getResultList();
    }

}
