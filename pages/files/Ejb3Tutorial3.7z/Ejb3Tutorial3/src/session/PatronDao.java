package session;

import entity.Address;
import entity.Patron;

/**
 * This class supports basic create, read, update, delete functionality for the
 * Patron. As with Book, as we implement more requirements we'll be revisiting
 * this class to extend its functionality.
 */
public class PatronDao extends BaseDao {
    public Patron createPatron(final String fname, final String lname,
            final String phoneNumber, final Address a) {
        final Patron p = new Patron(fname, lname, phoneNumber, a);
        getEm().persist(p);
        return p;
    }

    public Patron retrieve(final Long id) {
        return getEm().find(Patron.class, id);
    }

    public void removePatron(final Long id) {
        final Patron p = retrieve(id);
        if (p != null) {
            getEm().remove(p);
        }
        getEm().flush();
    }

    public Patron update(final Patron p) {
        return getEm().merge(p);
    }
}
