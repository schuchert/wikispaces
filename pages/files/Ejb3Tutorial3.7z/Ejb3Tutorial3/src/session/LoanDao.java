package session;

import java.util.Date;
import java.util.List;

import javax.persistence.NoResultException;

import entity.Loan;
import entity.Patron;
import entity.Resource;

/**
 * Provide some basic queries focused around the Loan object. These queries
 * could have been placed in either the PatronDao or ResourceDao. However,
 * neither seemed like quite the right place so we created this new Dao.
 */
public class LoanDao extends BaseDao {

    /**
     * Given a resource id, find the associated loan or return null if none
     * found.
     * 
     * @param resrouceId
     *            Id of resource on loan
     * 
     * @return Loan object that holds onto resourceId
     */
    public Loan getLoanFor(Long resourceId) {
        try {
            return (Loan) getEm().createNamedQuery("Loan.byResourceId")
                    .setParameter("resourceId", resourceId).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public void remove(final Loan l) {
        getEm().remove(l);
    }

    /**
     * Return resources that are due after the compareDate.
     * 
     * @param compareDate
     *            If a resource's due date is after compareDate, then it is
     *            included in the list. Note that this named query uses
     *            projection. Have a look at Loan.java.
     * 
     * @return a list of all the resources that were due after this date.
     */
    @SuppressWarnings("unchecked")
    public List<Resource> listAllOverdueResources(final Date compareDate) {
        return getEm().createNamedQuery("Loan.overdueResources").setParameter(
                "date", compareDate).getResultList();
    }

    /**
     * Essentially the same query as listAllOverdueResources but we return the
     * Patrons instead of the resources. This method uses a named query that
     * uses projection.
     * 
     * @param compareDate
     *            If a patron has at least one resources that was due after the
     *            compare date, include them.
     * 
     * @return A list of the patrons with at least one overdue resources
     */
    @SuppressWarnings("unchecked")
    public List<Patron> listAllPatronsWithOverdueResources(
            final Date compareDate) {
        return getEm().createNamedQuery("Loan.patronsWithOverdueResources")
                .setParameter("date", compareDate).getResultList();
    }

    /**
     * Return all resources on loan to the provided patron id.
     * 
     * @param patronId
     *            If patron id is invalid, this method will not notice it.
     * 
     * @return Zero or more resources on loan to the patron in question
     */
    @SuppressWarnings("unchecked")
    public List<Resource> listResourcesOnLoanTo(final Long patronId) {
        return getEm().createNamedQuery("Loan.resourcesLoanedTo").setParameter(
                "patronId", patronId).getResultList();
    }
}
