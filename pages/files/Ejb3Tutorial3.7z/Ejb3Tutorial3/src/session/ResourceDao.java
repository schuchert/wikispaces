package session;

import entity.Resource;

/**
 * This class offers the basic create, read, update, delete functions required
 * for a resource. As we implement more complex requirements, we'll be coming
 * back to this class to add additional queries.
 */
public class ResourceDao extends BaseDao {
    public void create(final Resource r) {
        getEm().persist(r);
    }

    public Resource retrieve(final Long id) {
        return getEm().find(Resource.class, id);
    }

    public void remove(Long id) {
        final Resource r = retrieve(id);
        if (r != null) {
            getEm().remove(r);
        }
        getEm().flush();
    }

    public Resource update(Resource r) {
        return getEm().merge(r);
    }

    public Resource findById(Long id) {
        return getEm().find(Resource.class, id);
    }
}
