package entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * I'm an entity with a 2-part key. The first part of my key is a Resource id, the
 * second is a Patron id.
 * <P>
 * To make this work, we must do several things: Use the annotation IdClass,
 * Specify each of the parts of the id by using Id annotation (2 times in this
 * case), Set each Id column to both insertable = false and updatable = false,
 * Create an attribute representing the type of the id (Resource, Patron), Use
 * JoinColumn with the name = id and insertable = false, updatable = false.
 */

@Entity
@IdClass(LoanId.class)
@NamedQueries( {
        @NamedQuery(name = "Loan.resourcesLoanedTo", query = "SELECT l.resource FROM Loan l WHERE l.patron.id = :patronId"),
        @NamedQuery(name = "Loan.byResourceId", query = "SELECT l FROM Loan l WHERE l.resourceId = :resourceId"),
        @NamedQuery(name = "Loan.overdueResources", query = "SELECT l.resource FROM Loan l WHERE l.dueDate < :date"),
        @NamedQuery(name = "Loan.patronsWithOverdueResources", query = "SELECT l.patron FROM Loan l WHERE l.dueDate < :date") })
public class Loan {
    /**
     * Part 1 of a 2-part Key. The name must match the name in LoanId.
     */
    @Id
    @Column(name = "resourceId", insertable = false, updatable = false)
    private Long resourceId;

    /**
     * Part 2 of a 2-part Key. The name must match the name in LoanId.
     */
    @Id
    @Column(name = "patronId", insertable = false, updatable = false)
    private Long patronId;

    /**
     * A duplicate column in a sense, this one gives us the actual Patron rather
     * than just having the id of the Patron.
     * 
     * In the reference material I read, putting in insertable and updatable =
     * false did not seem required. However, when using the hibernate entity
     * manger I got a null pointer exception and had to step through the source
     * code to fix the problem.
     */
    @ManyToOne
    @JoinColumn(name = "patronId", insertable = false, updatable = false)
    private Patron patron;

    /**
     * Same comment as for patron attribute above.
     */
    @ManyToOne
    @JoinColumn(name = "resourceId", insertable = false, updatable = false)
    private Resource resource;

    /**
     * The date type can represent a date, a time or a time stamp (date and
     * time). In our case we just want the date.
     */
    @Temporal(TemporalType.DATE)
    @Column(updatable = false)
    private Date checkoutDate;

    @Temporal(TemporalType.DATE)
    @Column(updatable = false)
    private Date dueDate;

    public Loan() {
    }

    public Loan(final Resource r, final Patron p, final Date checkoutDate) {
        setResourceId(r.getId());
        setPatronId(p.getId());
        setResource(r);
        setPatron(p);
        setCheckoutDate(checkoutDate);
        setDueDate(r.calculateDueDateFrom(checkoutDate));
    }

    public Resource getResource() {
        return resource;
    }

    public void setResource(final Resource resource) {
        this.resource = resource;
    }

    public Long getResourceId() {
        return resourceId;
    }

    public void setResourceId(final Long resourceId) {
        this.resourceId = resourceId;
    }

    public Date getCheckoutDate() {
        return checkoutDate;
    }

    public void setCheckoutDate(final Date checkoutDate) {
        this.checkoutDate = checkoutDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(final Date dueDate) {
        this.dueDate = dueDate;
    }

    public Patron getPatron() {
        return patron;
    }

    public void setPatron(final Patron patron) {
        this.patron = patron;
    }

    public Long getPatronId() {
        return patronId;
    }

    public void setPatronId(final Long patronId) {
        this.patronId = patronId;
    }

    public void checkin(final Date checkinDate) {
        getResource().checkin(checkinDate);
        getPatron().checkin(this);
    }
}
