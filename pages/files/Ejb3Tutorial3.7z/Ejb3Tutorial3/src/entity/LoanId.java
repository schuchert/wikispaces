package entity;

import java.io.Serializable;

/**
 * I'm a custom, multi-part key. I represent the key of a Loan object, which
 * consists of a Patron id and a Resource id.
 * 
 * These two values together must be unique. The names of my attributes are the
 * same as the names used in Loan (patronId, rescoureId).
 * 
 * I also must be Serializable.
 */
public class LoanId implements Serializable {
    private static final long serialVersionUID = -2947379879626719748L;
    /**
     * The following two fields must have names that match the names used in the
     * Loan class.
     */
    private Long patronId;
    private Long resourceId;

    public LoanId() {
    }

    public LoanId(final Long patronId, final Long resourceId) {
        this.patronId = patronId;
        this.resourceId = resourceId;
    }

    public Long getResourceId() {
        return resourceId;
    }

    public Long getPatronId() {
        return patronId;
    }

    @Override
    public boolean equals(final Object rhs) {
        return rhs instanceof LoanId
                && ((LoanId) rhs).resourceId.equals(resourceId)
                && ((LoanId) rhs).patronId.equals(patronId);
    }

    @Override
    public int hashCode() {
        return patronId.hashCode() * resourceId.hashCode();
    }
}
