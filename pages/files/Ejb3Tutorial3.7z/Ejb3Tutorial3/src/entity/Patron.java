package entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;

import exception.InsufficientFunds;

@Entity
public class Patron {
    @Id
    @GeneratedValue
    private Long id;

    @Embedded
    private Name name;

    @Column(length = 11, nullable = false)
    private String phoneNumber;

    /**
     * This next field refers to an object that is stored in another table. All
     * updates are cascaded. So if you persist me, my address, which is in
     * another table, will be persisted automatically. Updates and removes are
     * also cascaded automatically. This is required in the database because I
     * did not include "optional = true" in the annotation.
     * 
     * Note that cascading removes is a bit dangerous. In this case I know that
     * the address is owned by only one Patron. In general you need to be
     * careful automatically removing objects in related tables due to possible
     * constraint violations.
     */
    @OneToOne(cascade = CascadeType.ALL)
    private Address address;

    /**
     * A Patron may have several resources on loan.
     */
    @OneToMany(mappedBy = "patron", cascade = { CascadeType.PERSIST,
            CascadeType.MERGE })
    private List<Loan> checkedOutResources;

    /**
     * I have zero to many fines. The fines are ordered by the date they were
     * added to me.
     */
    @OneToMany(cascade = CascadeType.ALL)
    @OrderBy("dateAdded")
    private List<Fine> fines;

    public Patron(final String fName, final String lName, final String phone,
            final Address a) {
        setName(new Name(fName, lName));
        setPhoneNumber(phone);
        setAddress(a);
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public List<Loan> getCheckedOutResources() {
        if (checkedOutResources == null) {
            checkedOutResources = new ArrayList<Loan>();
        }

        return checkedOutResources;
    }

    public void setCheckedOutResources(List<Loan> checkedOutResources) {
        this.checkedOutResources = checkedOutResources;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public void removeLoan(final Loan loan) {
        getCheckedOutResources().remove(loan);
    }

    public void addLoan(Loan l) {
        getCheckedOutResources().add(l);
    }

    public List<Fine> getFines() {
        if (fines == null) {
            fines = new ArrayList<Fine>();
        }
        return fines;
    }

    public void setFines(List<Fine> fines) {
        this.fines = fines;
    }

    public void checkout(final Resource r, final Date checkoutDate) {
        final Loan l = new Loan(r, this, checkoutDate);
        getCheckedOutResources().add(l);
        r.setLoan(l);
    }

    public void addFine(final Fine f) {
        getFines().add(f);
    }

    public void checkin(final Loan loan) {
        getCheckedOutResources().remove(loan);
    }

    public double calculateTotalFines() {
        double sum = 0;
        for (Fine f : getFines()) {
            sum += f.getAmount();
        }

        return sum;
    }

    /**
     * I clear fines depending on amount tendered. Note that the cascade mode is
     * set to all, so if I delete records from my set, they will be removed from
     * the database.
     * 
     * @param amountTendered
     * 
     * @return balance after the payment
     */

    public double pay(final double amountTendered) {
        double totalFines = calculateTotalFines();
        if (totalFines <= amountTendered) {
            setFines(new ArrayList<Fine>());
            return amountTendered - totalFines;
        } else {
            throw new InsufficientFunds();
        }
    }
}
