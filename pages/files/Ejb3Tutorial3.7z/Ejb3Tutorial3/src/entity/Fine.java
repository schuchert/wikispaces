package entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * I represent a single fine assigned to a Patron for a resource returned after its
 * due date.
 * 
 * I use new new features of JPA.
 */
@Entity
public class Fine {
    @Id
    @GeneratedValue
    private Long id;
    private double amount;

    @Temporal(TemporalType.DATE)
    private Date dateAdded;

    @OneToOne
    private Resource resource;

    public Fine() {
    }

    public Fine(final double amount, final Date dateAdded,
            final Resource resource) {
        setAmount(amount);
        setDateAdded(dateAdded);
        setResource(resource);
    }

    public Resource getResource() {
        return resource;
    }

    public void setResource(final Resource resource) {
        this.resource = resource;
    }

    public Date getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(Date dateAdded) {
        this.dateAdded = dateAdded;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double fine) {
        this.amount = fine;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
