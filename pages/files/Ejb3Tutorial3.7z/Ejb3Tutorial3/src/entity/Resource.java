package entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;

import util.DateTimeUtil;

/**
 * I represent the base of all things that can be checked of the Library. I hold
 * the ID field for all kinds of resources.
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Resource {
    /**
     * You do not (cannot in fact) add an id field to any subclasses since they
     * already inherit it from me.
     */
    @Id
    @GeneratedValue
    private Long id;

    /**
     * This was a book attribute, now it is moved up to Resource from Book (and
     * remove from Book).
     */
    @Column(length = 125, nullable = false)
    private String title;

    /**
     * This was a book attribute but since it makes sense for all resources, it
     * is now here and inherited by all subclasses of resources.
     * 
     * Now, instead of directly knowing the patron who has borrowed me as in the
     * previous version, I now hold on to a Loan object. The loan tracks both
     * me, the patron as well as the checkout and due dates.
     */
    @OneToOne(mappedBy = "resource", cascade = CascadeType.PERSIST, optional = true)
    private Loan loan;

    public Resource() {
    }

    public Resource(final String title) {
        this.title = title;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Each kind of resource has different rules for how long it can be checked
     * out. This abstract method forces each kind of resource to specify its due
     * date.
     * 
     * @param checkoutDate
     *            The date from which to calculate the due date
     * 
     * @return The date the resource is due back
     */
    public abstract Date calculateDueDateFrom(final Date checkoutDate);

    /**
     * Calculate the fine for a given resource based on the number of days late
     * the Patron returned it.
     * 
     * @param daysLate
     *            Number of days this resource is late
     * 
     * @return The fine
     */
    public abstract double calculateFine(final int daysLate);

    /**
     * This was in Book but you check in all resources. Notice that this method
     * does not know how to calculate the actual fine, so it delegates the fine
     * calculation to the derived class. This method is an example of the
     * Template Method Pattern.
     * 
     * @param checkinDate
     */
    public void checkin(final Date checkinDate) {
        final Date dueDate = getDueDate();

        if (getLoan().getDueDate().before(checkinDate)) {
            int daysLate = DateTimeUtil.daysBetween(dueDate, checkinDate);
            final double fineAmount = calculateFine(daysLate);
            final Fine f = new Fine(fineAmount, checkinDate, this);
            getLoan().getPatron().addFine(f);
        }

        setLoan(null);
    }

    public boolean isOnLoanTo(final Patron p) {
        return (getLoan() == null && p == null) || getLoan() != null
                && getLoan().getPatron().equals(p);
    }

    public boolean isCheckedOut() {
        return getLoan() != null;
    }

    public boolean dueDateEquals(final Date date) {
        return (date == null && !isCheckedOut())
                || getLoan().getDueDate().equals(date);
    }

    public Date getDueDate() {
        if (isCheckedOut()) {
            return getLoan().getDueDate();
        }
        return null;
    }
}
