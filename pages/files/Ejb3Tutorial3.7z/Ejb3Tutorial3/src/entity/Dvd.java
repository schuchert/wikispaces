package entity;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

/**
 * Notice that to get this to "work" all we need to do is inherit from Resource.
 * As with book, we do not define an id field, since it is inherited.
 * 
 * The way this class is represented in the database is determined by meta
 * information in the Resource base class.
 * 
 * Of course, regular Java rules apply here. The Resource base class defines 2
 * abstract methods, both of which are overridden here.
 */
@Entity
public class Dvd extends Resource {
    @ManyToOne(cascade = { CascadeType.MERGE, CascadeType.PERSIST })
    private Director director;

    @Override
    public Date calculateDueDateFrom(final Date checkoutDate) {
        final Calendar c = Calendar.getInstance();
        c.setTime(checkoutDate);
        c.add(Calendar.DATE, 6);
        return c.getTime();
    }

    @Override
    public double calculateFine(final int daysLate) {
        if (daysLate < 5) {
            return .3 * daysLate;
        }

        if (daysLate < 10) {
            return .6 * daysLate;
        }

        return 6.0;
    }

    public Director getDirector() {
        return director;
    }

    public void setDirector(Director director) {
        this.director = director;
    }
}
