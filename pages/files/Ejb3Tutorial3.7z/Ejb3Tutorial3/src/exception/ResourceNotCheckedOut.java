package exception;

/**
 * A simple unchecked exception reflecting a particular business rule violation.
 * A resource cannot be checked out if it is already checked out.
 * 
 * This exception inherits from RuntimeException (or it is an unchecked
 * exception). Why? The policy of whether to use checked or unchecked exceptions
 * is project dependent. We are using this for learning about EJB3 and JPA and
 * NOT about how to write exceptions, so using one policy versus the other is
 * arbitrary for our purposes. Working with unchecked exceptions is a bit looser
 * but also keeps the code looking a bit cleaner, so we've gone with unchecked
 * exceptions.
 */
public class ResourceNotCheckedOut extends RuntimeException {
    private static final long serialVersionUID = 2286908621531520488L;

    final Long resourceId;

    public ResourceNotCheckedOut(final Long resourceId) {
        this.resourceId = resourceId;
    }

    public Long getBookId() {
        return resourceId;
    }
}
