package exception;

/**
 * Thrown when a Patron attempts to pay less that then total fines owed.
 */
public class InsufficientFunds extends RuntimeException {
    private static final long serialVersionUID = -735261730912439200L;
}
