package exception;

/**
 * Thrown when Patron attempts to checkout a resource but has fines.
 */
public class PatronHasFines extends RuntimeException {
    private static final long serialVersionUID = 2868510410691634148L;

    double totalFines;

    public PatronHasFines(final double amount) {
        this.totalFines = amount;
    }

    public double getTotalFines() {
        return totalFines;
    }
}
