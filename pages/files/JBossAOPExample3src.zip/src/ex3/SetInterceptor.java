package ex3;

import java.lang.reflect.Field;

import org.jboss.aop.advice.Interceptor;
import org.jboss.aop.joinpoint.FieldWriteInvocation;
import org.jboss.aop.joinpoint.Invocation;

public class SetInterceptor implements Interceptor {
	public String getName() {
		return "SetInterceptor";
	}

	public Object invoke(Invocation invocation) throws Throwable {
		if (!(invocation instanceof FieldWriteInvocation))
			return invocation.invokeNext();

		FieldWriteInvocation mi = (FieldWriteInvocation) invocation;
		Object newValue = mi.getValue();
		Object target = mi.getTargetObject();
		Field field = mi.getField();
		Object currentValue = field.get(target);

		if (equals(currentValue, newValue)) {
			return null;
		} else {
			((ITrackedObject) target).setChanged(true);
			return invocation.invokeNext();
		}
	}

	private boolean equals(Object lhs, Object rhs) {
		if (lhs == null && rhs == null) {
			return true;
		}
		if (lhs == null && rhs != null) {
			return false;
		}
		if (lhs != null && rhs == null) {
			return false;
		}
		return lhs.equals(rhs);
	}
}
