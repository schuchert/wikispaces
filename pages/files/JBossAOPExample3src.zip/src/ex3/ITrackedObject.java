package ex3;

public interface ITrackedObject {
	boolean isChanged();
	void setChanged(boolean changed);
}
