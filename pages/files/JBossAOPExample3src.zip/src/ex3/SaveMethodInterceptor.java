package ex3;

import org.jboss.aop.joinpoint.Invocation;
import org.jboss.aop.joinpoint.MethodInvocation;
import org.jboss.aop.advice.Interceptor;

public class SaveMethodInterceptor implements Interceptor {
	public String getName() {
		return "SaveMethodInterceptor";
	}

	public Object invoke(Invocation invocation) throws Throwable {
		MethodInvocation mi = (MethodInvocation) invocation;
		Object param = mi.getArguments()[0];
		ITrackedObject tracked = (ITrackedObject)param;
		
		try
		{
			if(tracked.isChanged())
			{
				return invocation.invokeNext();
			}
			else
			{
				System.out.printf("Not saving: %s, it is unchanged\n", param.getClass());
				return null;
			}
		}
		finally
		{
			tracked.setChanged(false);
		}
	}
}
