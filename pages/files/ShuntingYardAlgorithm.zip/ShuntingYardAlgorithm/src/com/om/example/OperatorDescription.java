package com.om.example;

public class OperatorDescription {
   public enum Associativity {
      Left, Right
   };

   public final String name;
   public final int precedence;
   public final Associativity associativity;

   public OperatorDescription(String name, int precedence, Associativity associativity) {
      this.name = name;
      this.precedence = precedence;
      this.associativity = associativity;
   }

   public boolean occursBefore(OperatorDescription nextToken) {
      if (associativity == Associativity.Left)
         return precedence >= nextToken.precedence;

      return precedence > nextToken.precedence;
   }

   public String toString() {
      return String.format("{%3s|%2d|%5s}", name, precedence, associativity);
   }
}
