package com.om.example;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;

import com.om.example.OperatorDescription.Associativity;

public class OperatorDescriptionFactory {
   private static OperatorDescriptionFactory instance = new OperatorDescriptionFactory();
   private ConcurrentHashMap<String, OperatorDescription> tokenMap = new ConcurrentHashMap<String, OperatorDescription>();

   protected OperatorDescriptionFactory() {
      register("(", -10, Associativity.Left);
      register(")", -10, Associativity.Left);
      register("%", 100, Associativity.Right);
      register("*", 100, Associativity.Left);
      register("/", 100, Associativity.Left);
      register("+", 10, Associativity.Left);
      register("-", 10, Associativity.Left);
      register(",", -999, Associativity.Left);
      register("&=", -10, Associativity.Right);
      register("^=", -10, Associativity.Right);
      register("|=", -10, Associativity.Right);
      register("<<=", -9, Associativity.Right);
      register(">>=", -9, Associativity.Right);
      register("*=", -8, Associativity.Right);
      register("/=", -8, Associativity.Right);
      register("%=", -8, Associativity.Right);
      register("+=", -7, Associativity.Right);
      register("-=", -7, Associativity.Right);
      register("=", -6, Associativity.Right);
      register("||", -5, Associativity.Left);
      register("&&", -4, Associativity.Left);
      register("|", -3, Associativity.Left);
      register("^", -2, Associativity.Left);
      register("&", -1, Associativity.Left);
      register("==", 0, Associativity.Left);
      register("!=", 0, Associativity.Left);
      register(">", 1, Associativity.Left);
      register(">=", 1, Associativity.Left);
      register("<", 2, Associativity.Left);
      register("<=", 2, Associativity.Left);
      register("<<", 3, Associativity.Left);
      register(">>", 3, Associativity.Left);
   }

   private void register(String name, int precedence, Associativity associativity) {
      tokenMap.put(name, new OperatorDescription(name, precedence, associativity));
   }

   public static OperatorDescription getOperatorNamed(String operatorName) {
      OperatorDescription op = instance.tokenMap.get(operatorName);
      if (op == null)
         throw new RuntimeException(String.format("Unknown Operator: %s", operatorName));
      return op;
   }

   public static Collection<OperatorDescription> listAll() {
      return instance.tokenMap.values();
   }
}
