package com.om.example;

import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExpressionTokenizer implements Iterable<String>, Iterator<String> {
   private static final Pattern TOKEN = Pattern
         .compile("^\\s*(\\d+\\.?\\d*|[a-zA-Z$_][\\w$]*|>>=|<<=|[-<>+=]{2}|[-|&=*~!/+*<>,]|[!+-|^<>]=|[()])\\s*");

   private Matcher matcher;

   public ExpressionTokenizer(String expression) {
      matcher = TOKEN.matcher(expression != null ? expression.trim() : "");
   }

   public boolean hasNext() {
      return matcher.lookingAt() || assertFinished();
   }

   public String next() {
      if (hasNext())
         return nextToken();

      throw new RuntimeException();
   }

   private boolean assertFinished() {
      if (!(matcher.regionStart() == matcher.regionEnd()))
         throw new RuntimeException(matcher.appendTail(new StringBuffer("Parse error on: "))
               .toString());
      return false;
   }

   private String nextToken() {
      String token = matcher.group(1);
      matcher.region(matcher.end(), matcher.regionEnd());
      return token;
   }

   public Iterator<String> iterator() {
      return this;
   }

   public void remove() {
      next();
   }

   public String peek() {
      int regionStart = matcher.regionStart();
      int regionEnd = matcher.regionEnd();
      String token = next();
      matcher.region(regionStart, regionEnd);
      return token;
   }
}
