package com.om.example;

import static com.om.example.OperatorDescriptionFactory.getOperatorNamed;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class OperatorDescriptionTest {
   OperatorDescription times = getOperatorNamed("*");
   OperatorDescription plus = getOperatorNamed("+");
   OperatorDescription minus = getOperatorNamed("-");
   OperatorDescription bitwiseOr = getOperatorNamed("|");
   OperatorDescription bitwiseAnd = getOperatorNamed("&");

   private OperatorDescription lhs;

   private OperatorDescriptionTest check(String opName) {
      this.lhs = getOperatorNamed(opName);
      return this;
   }

   private OperatorDescriptionTest check(OperatorDescription lhs) {
      this.lhs = lhs;
      return this;
   }

   private OperatorDescriptionTest isBefore(String operatorName) {
      return isBefore(getOperatorNamed(operatorName));
   }
   
   private OperatorDescriptionTest isBefore(OperatorDescription rhs) {
      assertTrue(lhs.occursBefore(rhs));
      return this;
   }

   private void isAfter(String opName) {
      isAfter(getOperatorNamed(opName));
   }
   
   private void isAfter(OperatorDescription rhs) {
      assertTrue(!lhs.occursBefore(rhs));
   }

   private void isSameAs(String opName) {
      OperatorDescription rhs = getOperatorNamed(opName);
      OperatorDescription lhs = this.lhs;
      isAfter(rhs);
      check(rhs).isAfter(lhs);
   }

   @Test
   public void verifyAssignmentByBitwise() {
      check("&=").isSameAs("&=");
      check("&=").isSameAs("^=");
      check("&=").isSameAs("&=");
   }
   
   @Test
   public void verifyAssignmentBitwise() {
      check("<<=").isSameAs("<<=");
      check("<<=").isSameAs(">>=");
   }
   
   @Test
   public void verifyAssignmentProdQuotMod() {
      check("*=").isSameAs("*=");
      check("*=").isSameAs("/=");
      check("*=").isSameAs("%=");
   }

   @Test
   public void verifyAssignmentBySumAndDifference() {
      check("+=").isSameAs("+=");
      check("+=").isSameAs("-=");
   }
   
   @Test
   public void verifyAssignment() {
      check("=").isSameAs("=");
   }

   @Test
   public void verifyAssignmentGrouping() {
      check("&=").isAfter("<<=");
      check("<<=").isAfter("*=");
      check("*=").isAfter("+=");
      check("+=").isAfter("=");
   }
   
   @Test
   public void verifyLogicalOperators() {
      check("||").isBefore("||");
      check("||").isAfter("&&");
      check("&&").isBefore("&&");
   }
   
   @Test
   public void verifyLogicalOrBeforeEquals() {
      check("||").isBefore("=");
   }
   
   @Test
   public void verifyBitwiseOperators() {
      check("|").isBefore("|").isAfter("^");
      check("^").isBefore("^").isAfter("&");
   }
   
   @Test
   public void checkbitwiseOrAnd() {
      check(bitwiseAnd).isBefore(bitwiseOr);
      check(bitwiseOr).isAfter(bitwiseAnd);
   }

   @Test
   public void itShouldReportTrueForEqualLeftAssociativePrecedence() {
      check(plus).isBefore(minus);
      check(minus).isBefore(plus);
   }

   @Test
   public void itShouldReportPlusBeforeTimesAsFalse() {
      check(plus).isAfter(times);
   }

   @Test
   public void itShouldReportTimesBeforePlusAsTrue() {
      check(times).isBefore(plus);
   }
}
