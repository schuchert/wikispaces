package com.om.example;

import static com.om.example.OperatorDescriptionFactory.getOperatorNamed;

import java.util.Stack;

public class InfixToPostfixConverter {
   private static final String LEFT_PAREN = "(";
   private static final String RIGHT_PAREN = ")";

   ExpressionTokenizer et;
   Stack<String> pendingTokens;
   private String result;

   public String translate(String expression) {
      initialize(expression);
      translate();
      return result;
   }

   private void initialize(String expression) {
      result = "";
      pendingTokens = new Stack<String>();
      et = new ExpressionTokenizer(expression);
   }

   private void translate() {
      while (et.hasNext())
         processOneToken();

      flushPendingTokens();
   }

   private String processOneToken() {
      String token = et.next();

      if (isFunction(token))
         handleFunction(token);
      else if (ifArgumentSeparator(token))
         handleArgumentSeparator(token);
      else if (isLiteral(token))
         handleLiteral(token);
      else if (isLeftParen(token))
         handleLeftParen();
      else if (isRightParen(token))
         handleRightParen();
      else
         handleOperator(token);

      return result;
   }

   private void flushPendingTokens() {
      while (pendingTokens.size() > 0)
         addToResult(pendingTokens.pop());
   }

   private void addToResult(String value) {
      String filler = result.length() > 0 ? " " : "";
      result = String.format("%s%s%s", result, filler, value);
   }

   private boolean ifArgumentSeparator(String token) {
      return token.equals(",");
   }

   private void handleArgumentSeparator(String token) {
      addHigherPrecedenceOperatorsToResult(token);
   }

   private void handleFunction(String token) {
      pendingTokens.push(token);
      et.next();
   }

   private boolean isFunction(String token) {
      return isVariable(token) && nextTokenIsCallStart();
   }

   private boolean nextTokenIsCallStart() {
      return et.hasNext() && et.peek().equals(LEFT_PAREN);
   }

   private void handleLeftParen() {
      pendingTokens.push(LEFT_PAREN);
   }

   private void handleRightParen() {
      while (operatorsRemain() && topOperatorIsNotLeftParen())
         addToResult(pendingTokens.pop());
      removeTopOperator();
   }

   private void removeTopOperator() {
      if (operatorsRemain())
         pendingTokens.pop();
   }

   private boolean topOperatorIsNotLeftParen() {
      return !pendingTokens.peek().equals(LEFT_PAREN);
   }

   private boolean operatorsRemain() {
      return !pendingTokens.isEmpty();
   }

   private boolean isLeftParen(String token) {
      return token.equals(LEFT_PAREN);
   }

   private boolean isRightParen(String token) {
      return token.equals(RIGHT_PAREN);
   }

   private boolean isLiteral(String token) {
      return isNumber(token) || isVariable(token);
   }

   private boolean isVariable(String token) {
      return token.matches("^\\w+$");
   }

   private void handleOperator(String token) {
      addHigherPrecedenceOperatorsToResult(token);
      pendingTokens.push(token);
   }

   private void addHigherPrecedenceOperatorsToResult(String token) {
      while (operatorsRemain() && topIsNotFunction() && topIsHigherPrecedenceThan(token))
         addToResult(pendingTokens.pop());
   }

   private boolean topIsNotFunction() {
      return !isVariable(pendingTokens.peek());
   }

   private void handleLiteral(String token) {
      addToResult(token);
   }

   private boolean topIsHigherPrecedenceThan(String token) {
      OperatorDescription topToken = getOperatorNamed(pendingTokens.peek());
      OperatorDescription nextToken = getOperatorNamed(token);

      return topToken.occursBefore(nextToken);
   }

   private boolean isNumber(String candidate) {
      return candidate.matches("^[+-]?\\d+[.]?\\d*$");
   }
}
