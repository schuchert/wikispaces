package com.om.example;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ExpressionTokenizerTest {
   private ExpressionTokenizer tokenizer;

   private void validateTokensOf(String expression, String... expected) {
      tokenizer = new ExpressionTokenizer(expression);

      for (String current : expected)
         assertEquals(current, tokenizer.next());

      assertEquals(false, tokenizer.hasNext());
   }

   private void canFullyParse(String expression) {
      tokenizer = new ExpressionTokenizer(expression);

      for (@SuppressWarnings("unused")
      String current : tokenizer)
         ;

      assertEquals(false, tokenizer.hasNext());
   }

   @Test
   public void itShouldReturnNoTokensForEmptyString() {
      tokenizer = new ExpressionTokenizer("");
      assertEquals(false, tokenizer.hasNext());
   }

   @Test
   public void itShouldReturnOneTokenForJustANumber() {
      validateTokensOf("42", "42");
   }

   @Test
   public void itShouldSplitANumberFollowedByOperator() {
      validateTokensOf("123+", "123", "+");
   }

   @Test
   public void itShouldSplitABinaryExpression() {
      validateTokensOf("99-134", "99", "-", "134");
   }

   @Test
   public void itShouldHandleSpacesInBinaryExpression() {
      validateTokensOf("99 - 134", "99", "-", "134");
   }

   @Test
   public void itShouldHandleWhitespacesAndTabsAtBeginningAndEnd() {
      validateTokensOf("  99\t -\t 134 ", "99", "-", "134");
   }

   @Test
   public void itShouldHandleVariableAndFunctionNames() {
      validateTokensOf("a == b", "a", "==", "b");
   }

   @Test
   public void itShouldHandleNullExpressionGracefully() {
      validateTokensOf(null);
   }

   @Test(expected = RuntimeException.class)
   public void itShouldHandleInvalidCharactersGracefully() {
      validateTokensOf("'", "'");
   }

   @Test
   public void itShouldProvideParensAsSeparateTokens() {
      validateTokensOf("()", "(", ")");
   }

   @Test
   public void itShouldHandleNumbersWithDecimalPlaces() {
      validateTokensOf("(3.42 + 6) * a", "(", "3.42", "+", "6", ")", "*", "a");
   }

   @Test(expected = RuntimeException.class)
   public void thisWorkHuh() {
      validateTokensOf("4 +'", "4", "+", "'");
   }

   @Test
   public void itShouldHandleThisBigExpression() {
      validateTokensOf("a_13(f(4+5,1+a*2,(8+b)*10))", "a_13", "(", "f", "(", "4", "+", "5",
            ",", "1", "+", "a", "*", "2", ",", "(", "8", "+", "b", ")", "*", "10", ")", ")");
   }

   @Test(expected = RuntimeException.class)
   public void doesItWork() {
      validateTokensOf("4 + 5 *  '", "4", "+", "5", "*", "'");
   }

   @Test
   public void thisWork() {
      validateTokensOf("value+++4", "value", "++", "+", "4");
   }

   @Test(expected=RuntimeException.class)
   public void whatAboutThis() {
      canFullyParse("5~�");
   }

   @Test
   public void yetAnotherTest() {
      validateTokensOf("(3+2)*7", "(", "3", "+", "2", ")", "*", "7");
   }

   @Test
   public void itShouldWorkWithNewForSyntax() {
      ExpressionTokenizer expressionTokenizer = new ExpressionTokenizer("(3+2)*7");

      int count = 0;
      for (@SuppressWarnings("unused")
      String s : expressionTokenizer) {
         ++count;
      }
      assertEquals(7, count);
   }

   @Test
   public void itCanPeekAhead() {
      ExpressionTokenizer tokenizer = new ExpressionTokenizer("f(3)");
      assertEquals("f", tokenizer.next());
      assertEquals("(", tokenizer.peek());
      assertEquals("(", tokenizer.next());
      assertEquals("3", tokenizer.next());
   }
   
   @Test(expected=RuntimeException.class)
   public void itShouldReportBogusOperatorCorrectly() {
      validateTokensOf("3@+2", "3", "@", "+", "2");
   }
}
