package com.om.example;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class InfixToPostfixConverterTest {
   private final String infix;
   private final String expectedPostfix;

   @Parameters
   public static Collection<String[]> data() {
      ArrayList<String[]> values = new ArrayList<String[]>();

      addTestCase(values, null, "");
      addTestCase(values, "", "");
      addTestCase(values, "45", "45");
      addTestCase(values, "+", "+");
      addTestCase(values, "3 + 8", "3 8 +");
      addTestCase(values, "2 + 9 - 6", "2 9 + 6 -");
      addTestCase(values, "2 + 9 * 6", "2 9 6 * +");
      addTestCase(values, "2 * 10 | 6", "2 10 * 6 |");
      addTestCase(values, "2 | 3 | 4", "2 3 | 4 |");
      addTestCase(values, "a | 3", "a 3 |");
      addTestCase(values, "(3 + 4)", "3 4 +");
      addTestCase(values, "(3 + 4) * 5", "3 4 + 5 *");
      addTestCase(values, "(3+(4-5))*6", "3 4 5 - + 6 *");
      addTestCase(values, "f(3)", "3 f");
      addTestCase(values, "f(g(4))", "4 g f");
      addTestCase(values, "f(3, 4, 19)", "3 4 19 f");
      addTestCase(values, "f(4+5,1+a*2,(8+b)*10)", "4 5 + 1 a 2 * + 8 b + 10 * f");
      addTestCase(values, "5 | 4 & 3 + 2 * 1 | 7", "5 4 3 2 1 * + & | 7 |");
      addTestCase(values, "4 5 +", "4 5 +");

      return values;
   }

   private static void addTestCase(ArrayList<String[]> values, String infix, String expected) {
      values.add(new String[] { infix, expected });
   }

   public InfixToPostfixConverterTest(String infix, String expectedPostfix) {
      this.infix = infix;
      this.expectedPostfix = expectedPostfix;
   }

   @Test
   public void checkTranslation() {
      InfixToPostfixConverter converter = new InfixToPostfixConverter();
      String result = converter.translate(infix);
      assertEquals(expectedPostfix, result);
   }
}
