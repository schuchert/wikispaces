package com.coco.dojo;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import com.coco.dojo.Operator.Associativity;

public class InfixToPostfixTranslator {

	private static final String BLANK = "";
	private static final String DELIMETER = " ";
	private String result;
	private Stack<String> operators = new Stack<String>();
	private Map<String, Operator> operatorPrecedence = new HashMap<String, Operator>();

	public InfixToPostfixTranslator() {
		operatorPrecedence.put("+", new Operator("+", 42, Associativity.Left));
		operatorPrecedence.put("-", new Operator("-", 42, Associativity.Left));
		operatorPrecedence.put("*", new Operator("*", 42 * 2,
				Associativity.Left));
		operatorPrecedence
				.put("(", new Operator("(", -132, Associativity.Left));
		operatorPrecedence
				.put(")", new Operator(")", -132, Associativity.Left));
		operatorPrecedence
				.put("=", new Operator("=", -13, Associativity.Right));
	}

	public String convert(String expression) {
		result = BLANK;
		for (String token : tokenize(expression)) {
			if (isLeftParen(token)) {
				handleLeftParen();
			} else if (isRightParen(token)) {
				handleRightParen();
			} else if (!isOperator(token)) {
				appendToResult(token);
			} else {
				appendPreviousOperator(token);
				operators.push(token);
			}
		}
		flushRemainingOperators();
		return result.trim();
	}

	private boolean isOperator(String token) {
		return operatorPrecedence.containsKey(token);
	}

	private void handleRightParen() {
		while (operators.peek() != "(") {
			appendToResult(operators.pop());
		}
		operators.pop();
	}

	private boolean isRightParen(String token) {
		return token.matches("\\)");
	}

	private void handleLeftParen() {
		operators.push("(");
	}

	private boolean isLeftParen(String token) {
		return token.matches("\\(");
	}

	private String[] tokenize(String expression) {
		return expression.split(DELIMETER);
	}

	private boolean isNumber(String token) {
		return token.matches("\\d+");
	}

	private void appendPreviousOperator(String currentOperator) {
		if (!operators.isEmpty()
				&& takesPrecedence(operators.peek(), currentOperator)) {
			appendToResult(operators.pop());
		}
	}

	private void flushRemainingOperators() {
		while (!operators.isEmpty()) {
			appendToResult(operators.pop());
		}
	}

	private boolean takesPrecedence(String previousOperator,
			String currentOperator) {
		Operator o2 = operatorPrecedence.get(previousOperator);
		Operator o1 = operatorPrecedence.get(currentOperator);
		return o2.takesPrecedenceOver(o1);
	}

	private void appendToResult(String token) {
		result += token + DELIMETER;
	}

}