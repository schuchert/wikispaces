package com.coco.dojo;

import static org.junit.Assert.*;

import org.junit.Test;

public class InfixToPostfixTranslatorTest {
	@Test
	public void itShouldRemoveUnnecessaryParens() {
		validateTranslation("( 3 + 8 )", "3 8 +");
	}
	
	@Test
	public void itShouldHandleGroupingCorrectly() {
		validateTranslation("( 3 + 8 ) * 6", "3 8 + 6 *");
	}
	
	@Test
	public void itShouldHandleNestedParens() {
		validateTranslation("( 3 + ( 8 - 1 ) ) * 6", "3 8 1 - + 6 *");
	}
	
	@Test
	public void itShouldHigherPrecedenceFirst(){
		validateTranslation("20 + 9 * 6", "20 9 6 * +");
	}
	
	@Test
	public void itShouldReturnEmptyStringGivenEmptyString() {
		validateTranslation("", "");
	}
	
	@Test
	public void itShouldReturnNumberGivenNumber() {
		validateTranslation("3", "3");
	}

	@Test
	public void itShouldHandleASingleBinaryExpression() {
		validateTranslation("3 + 8", "3 8 +");
	}
	
	@Test
	public void itShouldHandleASingleBinaryExpressionUsingVariables() {
		validateTranslation("a + 3", "a 3 +");
	}

	@Test
	public void itShouldHandleAssociationExpressions() {
		validateTranslation("a = b = 3", "a b 3 = =");
	}

	@Test
	public void itShouldHandleDualBinaryExpressionOfSamePrecedence() {
		validateTranslation("2 + 9 - 6", "2 9 + 6 -");
	}
	
	private void validateTranslation(String expression, String expected) {
		String result = new InfixToPostfixTranslator().convert(expression);
		assertEquals(expected, result);
	}
}