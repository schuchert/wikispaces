package com.coco.dojo;

public class Operator {
	public final String name;
	public final int precedence;
	public final Associativity associativity;

	public enum Associativity {
		Left, Right
	};

	public Operator(String name, int precedence, Associativity associativity) {
		this.name = name;
		this.precedence = precedence;
		this.associativity = associativity;
	}

	public boolean takesPrecedenceOver(Operator other) {
		if (other.associativity == Associativity.Left)
			return other.precedence <= precedence;
		else
			return other.precedence < precedence;
	}
}
