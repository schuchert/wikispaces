package annotation;

public class Main {
    public static void main(String args[]) {
        Address a = new Address();
        a.setIgnoredField("Ignored");
        Dao.save(a);
        a.setZip("75001");
        Dao.save(a);
    }
}
