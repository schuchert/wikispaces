package annotation;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.DeclareParents;

@Aspect
public class InnerTypeAspect {
    @DeclareParents(value = "annotation.Address", defaultImpl = annotation.TrackedObjectMixin.class)
    ITrackedObject trackedObject;
}
