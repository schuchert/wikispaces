package annotation;

import java.lang.reflect.Field;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.FieldSignature;

@Aspect
public class FieldSetAspect {
    @Pointcut("set(* annotation.TrackedObjectMixin.*)")
    public void trackedObject() {
    }

    @Pointcut("args(rhs) && set(!@annotation.IgnoreField * annotation.Address.*)")
    public void allFields(Object rhs) {
    }

    @Pointcut("cflow(execution(annotation.ITrackedObject+.new (..)))")
    public void constructors() {
    }

    @Around("allFields(rhs) && !trackedObject() && !constructors()")
    public Object trackFieldAssignment(ProceedingJoinPoint thisJoinPoint, Object rhs) throws Throwable {
        FieldSignature fs = (FieldSignature) thisJoinPoint.getSignature();

        Object target = thisJoinPoint.getTarget();
        Field field = fs.getField();
        field.setAccessible(true);
        Object currentValue = field.get(target);

        if (equals(currentValue, rhs)) {
            return null;
        } else {
            ((ITrackedObject) target).setChanged(true);
            return thisJoinPoint.proceed();
        }
    }

    private boolean equals(Object lhs, Object rhs) {
        if (lhs == null && rhs == null) {
            return true;
        }
        if (lhs == null && rhs != null) {
            return false;
        }
        if (lhs != null && rhs == null) {
            return false;
        }
        return lhs.equals(rhs);
    }
}