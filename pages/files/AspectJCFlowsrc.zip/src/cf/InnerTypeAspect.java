package cf;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.DeclareParents;

@Aspect
public class InnerTypeAspect {
    @DeclareParents(value = "cf.Address", defaultImpl = cf.TrackedObjectMixin.class)
    ITrackedObject trackedObject;
}
