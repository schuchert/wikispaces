package cf;

public interface ITrackedObject {
    boolean isChanged();

    void setChanged(boolean changed);
}
