package ex1;

public class MethodExecutionExample {
    public void noArgMethod() {
        System.out.printf("\tnoArgMethod\n");
    }

    public void methodWithStringParam(String param) {
        System.out.printf("\tmethodWithStringParam: %s\n", param);
    }

    public static void staticMethod() {
        System.out.printf("\tstaticMethod\n");
    }

    public void methodCallingOtherMethod() {
        System.out.printf("\tmethodCallingOtherMethod\n");
        noArgMethod();
    }
}