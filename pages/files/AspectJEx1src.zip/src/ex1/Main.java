package ex1;

public class Main {
    public static void main(String[] args) {
        MethodExecutionExample me = new MethodExecutionExample();

        me.noArgMethod();
        System.out.println("-------------");

        me.methodWithStringParam("Brett");
        System.out.println("-------------");

        me.methodCallingOtherMethod();
        System.out.println("-------------");

        MethodExecutionExample.staticMethod();
    }
}