package com.om.characterization;

public class RateCalculatorTest {

}
