package com.om.refactoring;

public class Site {
	public int kwh;
}
