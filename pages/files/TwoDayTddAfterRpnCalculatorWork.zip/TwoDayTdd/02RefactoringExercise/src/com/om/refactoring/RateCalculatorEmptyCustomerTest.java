package com.om.refactoring;

public class RateCalculatorEmptyCustomerTest extends RateCalculatorBaseTest {
    public void testBlankCustomerHas0Rate() {
        validateRate(0);
    }
}
