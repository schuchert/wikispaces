package com.om.switchtopolymorphism;

public class Site {
	public int kwh;
}
