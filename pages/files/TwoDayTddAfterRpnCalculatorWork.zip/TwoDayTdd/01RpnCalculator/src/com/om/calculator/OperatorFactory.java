package com.om.calculator;

public class OperatorFactory {

    public Operator retrieveOperatorNamed(String operatorName) {
        if ("+".equals(operatorName)) {
            return new Plus();
        } else if ("-".equals(operatorName)) {
            return new Minus();
        } else {
            return new Factorial();
        }
    }

}
