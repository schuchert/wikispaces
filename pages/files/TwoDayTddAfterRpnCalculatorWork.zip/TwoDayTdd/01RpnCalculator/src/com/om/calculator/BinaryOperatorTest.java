package com.om.calculator;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class BinaryOperatorTest {
    @Test
    public void performOperationCalledWithCorrectOperands() {
        OperandStack stack = new OperandStack();
        int leftOperand = 97;
        stack.push(leftOperand);

        int rightOperand = -43;
        stack.push(rightOperand);
        
        BinaryOperatorSpy spy = new BinaryOperatorSpy();
        
        spy.execute(stack);
        
        assertEquals(leftOperand, spy.actualLetOperator);
        assertEquals(rightOperand, spy.actualRightOperator);
    }

    @Test
    public void resultPutOnStack() {

        BinaryOperator operator = new BinaryOperator() {
            @Override
            protected int performOperation(int leftOperand, int rightOperand) {
                return 79;
            }
        };

        OperandStack stack = new OperandStack();
        operator.execute(stack);
        assertEquals(79, stack.top());
    }
}