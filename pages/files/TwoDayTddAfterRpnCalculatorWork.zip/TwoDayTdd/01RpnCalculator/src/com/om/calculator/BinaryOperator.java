package com.om.calculator;

public abstract class BinaryOperator implements Operator {

    public final void execute(OperandStack stack) {
        int rightOperand = stack.pop();
        int leftOperand = stack.pop();
        int result = performOperation(leftOperand, rightOperand);
        stack.push(result);
    }

    protected abstract int performOperation(int leftOperand, int rightOperand);
}
