package com.om.calculator;

import java.util.Stack;

public class OperandStack {
    private final Stack<Integer> values = new Stack<Integer>();

    public int pop() {
        if (values.isEmpty()) {
            return 0;
        }
        return values.pop();
    }

    public int top() {
        if (values.isEmpty()) {
            return 0;
        }
        return values.peek();
    }

    public void push(int value) {
        values.push(value);
    }
}
