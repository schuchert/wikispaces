package com.om.calculator;

public class Plus extends BinaryOperator {
    @Override
    protected int performOperation(int leftOperand, int rightOperand) {
        return leftOperand + rightOperand;
    }
}
