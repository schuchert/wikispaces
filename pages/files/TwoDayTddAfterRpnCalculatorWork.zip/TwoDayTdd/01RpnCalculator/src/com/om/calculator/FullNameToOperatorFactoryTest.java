package com.om.calculator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class FullNameToOperatorFactoryTest {
    private FullNameToOperatorFactory factory = new FullNameToOperatorFactory();

    @Test
    public void factorialRegistered() {
        Operator factorial = factory.retrieveOperatorNamed("factorial");
        assertNotNull(factorial);
        assertTrue(factorial instanceof Factorial);
    }

    @Test
    public void minusRegistered() {
        Operator minus = factory.retrieveOperatorNamed("minus");
        assertNotNull(minus);
        assertTrue(minus instanceof Minus);
    }

    @Test
    public void plusRegistered() {
        Operator plus = factory.retrieveOperatorNamed("plus");
        assertNotNull(plus);
        assertTrue(plus instanceof Plus);
    }
}
