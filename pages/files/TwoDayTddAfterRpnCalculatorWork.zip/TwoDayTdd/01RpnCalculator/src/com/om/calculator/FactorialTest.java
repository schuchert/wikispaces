package com.om.calculator;

import org.junit.Assert;
import org.junit.Test;

public class FactorialTest {
    Factorial factorial = new Factorial();
    OperandStack stack = new OperandStack();

    @Test
    public void factorialOf0is1() {
        stack.push(0);
        factorial.execute(stack);
        validateResultIs(1);
    }

    @Test
    public void factorialOfNIsCalculatedCorrectly() {
        stack.push(5);
        factorial.execute(stack);
        validateResultIs(120);
    }

    private void validateResultIs(int expected) {
        Assert.assertEquals(expected, stack.top());
    }

}
