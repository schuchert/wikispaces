package com.om.calculator;

public class RpnCalculator {
    private OperandStack values = new OperandStack();
    private OperatorFactory factory;

    public RpnCalculator(OperatorFactory factory) {
        this.factory = factory;
    }

    public void execute(String operatorName) {
        Operator operator = factory.retrieveOperatorNamed(operatorName);
        operator.execute(values);
    }

    public void enter(int value) {
        values.push(value);
    }

    public int top() {
        return values.top();
    }
}