package com.om.calculator;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class RpnCalculatorTest {
    private RpnCalculator calculator;

    @Before
    public void initializeCalculator() {
        calculator = new RpnCalculator(new OperatorFactory());
    }

    private void validateResultIs(int expectedValue) {
        int sum = calculator.top();
        assertEquals(expectedValue, sum);
    }

    @Test
    public void canExecuteAdd() {
        calculator.enter(4);
        calculator.enter(-21);
        calculator.execute("+");
        validateResultIs(4 + -21);
    }

    @Test
    public void canExecuteFactorial() {
        calculator.execute("!");
        validateResultIs(1);
    }

    @Test
    public void canSubtract() {
        calculator.enter(4);
        calculator.enter(-21);
        calculator.execute("-");
        validateResultIs(4 - -21);
    }

    @Test
    public void canAddEmpty() {
        calculator.execute("+");
        validateResultIs(0);
    }

    @Test
    public void threeNumberAddingOnlyLastTwo() {
        calculator.enter(3);
        calculator.enter(4);
        calculator.enter(4);
        calculator.execute("+");
        validateResultIs(8);
    }

    @Test
    public void canAddTwoNumbers() {
        calculator.enter(40);
        calculator.enter(-13);
        calculator.execute("+");
        validateResultIs(27);
    }
}
