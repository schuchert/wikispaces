package com.om.calculator;

public class Factorial implements Operator {
    public void execute(OperandStack stack) {
        int operand = stack.pop();
        int result = 1;
        for (int i = 2; i <= operand; ++i)
            result *= i;

        stack.push(result);
    }
}
