package com.om.calculator;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PlusTest {

    @Test
    public void canAddNumbers() {
        OperandStack stack = new OperandStack();
        stack.push(3);
        stack.push(10);
        
        Plus plus = new Plus();
        plus.execute(stack);
        
        assertEquals(13, stack.top());
    }
}
