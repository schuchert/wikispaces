package com.om.calculator;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class OperandStackTest {

    @Test
    public void canGetOperandFromEmptyStack() {
        OperandStack stack = new OperandStack();
        assertEquals(0, stack.pop());
    }
    
    @Test
    public void canGetTopOfEmptyStack() {
        OperandStack stack = new OperandStack();
        assertEquals(0, stack.top());
    }
    
    @Test
    public void canPushOneNumberOntoStack() {
        OperandStack stack = new OperandStack();
        stack.push(42);
        assertEquals(42, stack.top());
    }
}
