package com.om.calculator;

public class BinaryOperatorSpy extends BinaryOperator {
    public int actualLetOperator;
    public int actualRightOperator;

    @Override
    protected int performOperation(int leftOperand, int rightOperand) {
        actualLetOperator = leftOperand;
        actualRightOperator = rightOperand;
        return 0;
    }
};