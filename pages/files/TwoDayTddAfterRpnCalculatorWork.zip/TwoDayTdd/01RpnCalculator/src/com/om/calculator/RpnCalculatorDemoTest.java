package com.om.calculator;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class RpnCalculatorDemoTest {

    @Test
    public void normalCalculator() {
        RpnCalculator calculator = new RpnCalculator(new OperatorFactory());
        calculator.enter(34);
        calculator.enter(19);
        calculator.execute("+");
        assertEquals(34 + 19, calculator.top());
    }

    @Test
    public void fullNameCalculator() {
        RpnCalculator calculator = new RpnCalculator(new FullNameToOperatorFactory());
        calculator.enter(34);
        calculator.enter(19);
        calculator.execute("plus");
        assertEquals(34 + 19, calculator.top());
    }

}
