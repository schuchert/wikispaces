package com.om.calculator;

public interface Operator {
    void execute(OperandStack stack);
}
