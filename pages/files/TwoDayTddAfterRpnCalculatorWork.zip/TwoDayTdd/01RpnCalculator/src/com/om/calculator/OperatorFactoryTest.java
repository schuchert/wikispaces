package com.om.calculator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class OperatorFactoryTest {
    OperatorFactory factory;

    @Before
    public void setUp() {
        factory = new OperatorFactory();
    }

    @Test
    public void factorialRegistered() {
        Operator factorial = factory.retrieveOperatorNamed("!");
        assertNotNull(factorial);
        assertTrue(factorial instanceof Factorial);
    }

    @Test
    public void minusRegistered() {
        Operator minus = factory.retrieveOperatorNamed("-");
        assertNotNull(minus);
        assertTrue(minus instanceof Minus);
    }

    @Test
    public void plusRegistered() {
        Operator plus = factory.retrieveOperatorNamed("+");
        assertNotNull(plus);
        assertTrue(plus instanceof Plus);
    }
}
