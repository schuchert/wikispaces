package com.om.calculator;

import java.util.HashMap;
import java.util.Map;

public class FullNameToOperatorFactory extends OperatorFactory {
    Map<String, Operator> nameToOperator = new HashMap<String, Operator>();

    public FullNameToOperatorFactory() {
        nameToOperator.put("plus", new Plus());
        nameToOperator.put("minus", new Minus());
        nameToOperator.put("factorial", new Factorial());
    }

    public Operator retrieveOperatorNamed(String operatorName) {
        return nameToOperator.get(operatorName);
    }

}
