package net.jsunit.action;

import net.jsunit.RemoteServerHitter;

public interface RemoteRunnerHitterAware {

    public void setRemoteRunnerHitter(RemoteServerHitter hitter);

}
