package net.jsunit.action;

public interface LatestVersionSource {
    double getLatestVersion();
}
