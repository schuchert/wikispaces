package net.jsunit.action;

import net.jsunit.StandaloneTest;

public interface StandaloneTestAware {

    public void setStandaloneTest(StandaloneTest test);

}
