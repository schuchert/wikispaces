package net.jsunit.interceptor;

import net.jsunit.BrowserTestRunner;

public interface BrowserTestRunnerSource {

    BrowserTestRunner getRunner();

}
