package net.jsunit.version;

public interface VersionGrabber {
    double grabVersion() throws Exception;
}
