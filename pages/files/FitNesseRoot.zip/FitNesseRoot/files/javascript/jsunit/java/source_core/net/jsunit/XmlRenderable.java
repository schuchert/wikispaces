package net.jsunit;

import org.jdom.Element;

public interface XmlRenderable {

    Element asXml();

}
